// Version 1.10.1 horizon-timeseries-chart - https://github.com/vasturiano/horizon-timeseries-chart
!function(t, n) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = n() : "function" == typeof define && define.amd ? define(n) : (t = "undefined" != typeof globalThis ? globalThis : t || self).HorizonTSChart = n()
}(this, (function() {
    "use strict";
    function t(t, n) {
        var e = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
            var r = Object.getOwnPropertySymbols(t);
            n && (r = r.filter((function(n) {
                return Object.getOwnPropertyDescriptor(t, n).enumerable
            }
            ))),
            e.push.apply(e, r)
        }
        return e
    }
    function n(n) {
        for (var e = 1; e < arguments.length; e++) {
            var i = null != arguments[e] ? arguments[e] : {};
            e % 2 ? t(Object(i), !0).forEach((function(t) {
                r(n, t, i[t])
            }
            )) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(i)) : t(Object(i)).forEach((function(t) {
                Object.defineProperty(n, t, Object.getOwnPropertyDescriptor(i, t))
            }
            ))
        }
        return n
    }
    function e(t) {
        return e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        }
        : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        }
        ,
        e(t)
    }
    function r(t, n, e) {
        return (n = function(t) {
            var n = function(t, n) {
                if ("object" != typeof t || null === t)
                    return t;
                var e = t[Symbol.toPrimitive];
                if (void 0 !== e) {
                    var r = e.call(t, n || "default");
                    if ("object" != typeof r)
                        return r;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return ("string" === n ? String : Number)(t)
            }(t, "string");
            return "symbol" == typeof n ? n : String(n)
        }(n))in t ? Object.defineProperty(t, n, {
            value: e,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[n] = e,
        t
    }
    function i(t, n) {
        if (null == t)
            return {};
        var e, r, i = function(t, n) {
            if (null == t)
                return {};
            var e, r, i = {}, o = Object.keys(t);
            for (r = 0; r < o.length; r++)
                e = o[r],
                n.indexOf(e) >= 0 || (i[e] = t[e]);
            return i
        }(t, n);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(t);
            for (r = 0; r < o.length; r++)
                e = o[r],
                n.indexOf(e) >= 0 || Object.prototype.propertyIsEnumerable.call(t, e) && (i[e] = t[e])
        }
        return i
    }
    function o(t, n) {
        return function(t) {
            if (Array.isArray(t))
                return t
        }(t) || function(t, n) {
            var e = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (null != e) {
                var r, i, o, a, u = [], l = !0, s = !1;
                try {
                    if (o = (e = e.call(t)).next,
                    0 === n) {
                        if (Object(e) !== e)
                            return;
                        l = !1
                    } else
                        for (; !(l = (r = o.call(e)).done) && (u.push(r.value),
                        u.length !== n); l = !0)
                            ;
                } catch (t) {
                    s = !0,
                    i = t
                } finally {
                    try {
                        if (!l && null != e.return && (a = e.return(),
                        Object(a) !== a))
                            return
                    } finally {
                        if (s)
                            throw i
                    }
                }
                return u
            }
        }(t, n) || u(t, n) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }
    function a(t) {
        return function(t) {
            if (Array.isArray(t))
                return l(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"])
                return Array.from(t)
        }(t) || u(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }
    function u(t, n) {
        if (t) {
            if ("string" == typeof t)
                return l(t, n);
            var e = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === e && t.constructor && (e = t.constructor.name),
            "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? l(t, n) : void 0
        }
    }
    function l(t, n) {
        (null == n || n > t.length) && (n = t.length);
        for (var e = 0, r = new Array(n); e < n; e++)
            r[e] = t[e];
        return r
    }
    !function(t, n) {
        void 0 === n && (n = {});
        var e = n.insertAt;
        if (t && "undefined" != typeof document) {
            var r = document.head || document.getElementsByTagName("head")[0]
              , i = document.createElement("style");
            i.type = "text/css",
            "top" === e && r.firstChild ? r.insertBefore(i, r.firstChild) : r.appendChild(i),
            i.styleSheet ? i.styleSheet.cssText = t : i.appendChild(document.createTextNode(t))
        }
    }(".horizon-series {\n  position: relative;\n  border: 0 solid darkgray;\n}\n\n.horizon-series:hover {\n  border-top: 1px solid indianred;\n  border-bottom: 1px solid indianred;\n}\n\n.horizon-series .label {\n  position: absolute;\n  bottom: 0;\n  left: 4px;\n  font-family: sans-serif;\n  text-shadow: 0 1px 0 rgba(255, 255, 255, .5);\n  pointer-events: none;\n}\n\n.horizon-series .chart .horizon-tooltip {\n  z-index: 1000;\n}\n\n.horizon-ruler {\n  position: absolute;\n  background: black;\n  opacity: 0;\n  top: 0;\n  bottom: 0;\n  width: 5px;\n  pointer-events: none;\n  transition: opacity 0.5s;\n  z-index: 100;\n}");
    var s = "http://www.w3.org/1999/xhtml"
      , c = {
        svg: "http://www.w3.org/2000/svg",
        xhtml: s,
        xlink: "http://www.w3.org/1999/xlink",
        xml: "http://www.w3.org/XML/1998/namespace",
        xmlns: "http://www.w3.org/2000/xmlns/"
    };
    function f(t) {
        var n = t += ""
          , e = n.indexOf(":");
        return e >= 0 && "xmlns" !== (n = t.slice(0, e)) && (t = t.slice(e + 1)),
        c.hasOwnProperty(n) ? {
            space: c[n],
            local: t
        } : t
    }
    function h(t) {
        return function() {
            var n = this.ownerDocument
              , e = this.namespaceURI;
            return e === s && n.documentElement.namespaceURI === s ? n.createElement(t) : n.createElementNS(e, t)
        }
    }
    function p(t) {
        return function() {
            return this.ownerDocument.createElementNS(t.space, t.local)
        }
    }
    function d(t) {
        var n = f(t);
        return (n.local ? p : h)(n)
    }
    function y() {}
    function g(t) {
        return null == t ? y : function() {
            return this.querySelector(t)
        }
    }
    function v() {
        return []
    }
    function m(t) {
        return null == t ? v : function() {
            return this.querySelectorAll(t)
        }
    }
    function _(t) {
        return function() {
            return function(t) {
                return null == t ? [] : Array.isArray(t) ? t : Array.from(t)
            }(t.apply(this, arguments))
        }
    }
    function w(t) {
        return function() {
            return this.matches(t)
        }
    }
    function b(t) {
        return function(n) {
            return n.matches(t)
        }
    }
    var x = Array.prototype.find;
    function M() {
        return this.firstElementChild
    }
    var S = Array.prototype.filter;
    function C() {
        return Array.from(this.children)
    }
    function T(t) {
        return new Array(t.length)
    }
    function A(t, n) {
        this.ownerDocument = t.ownerDocument,
        this.namespaceURI = t.namespaceURI,
        this._next = null,
        this._parent = t,
        this.__data__ = n
    }
    function k(t, n, e, r, i, o) {
        for (var a, u = 0, l = n.length, s = o.length; u < s; ++u)
            (a = n[u]) ? (a.__data__ = o[u],
            r[u] = a) : e[u] = new A(t,o[u]);
        for (; u < l; ++u)
            (a = n[u]) && (i[u] = a)
    }
    function E(t, n, e, r, i, o, a) {
        var u, l, s, c = new Map, f = n.length, h = o.length, p = new Array(f);
        for (u = 0; u < f; ++u)
            (l = n[u]) && (p[u] = s = a.call(l, l.__data__, u, n) + "",
            c.has(s) ? i[u] = l : c.set(s, l));
        for (u = 0; u < h; ++u)
            s = a.call(t, o[u], u, o) + "",
            (l = c.get(s)) ? (r[u] = l,
            l.__data__ = o[u],
            c.delete(s)) : e[u] = new A(t,o[u]);
        for (u = 0; u < f; ++u)
            (l = n[u]) && c.get(p[u]) === l && (i[u] = l)
    }
    function z(t) {
        return t.__data__
    }
    function $(t) {
        return "object" == typeof t && "length"in t ? t : Array.from(t)
    }
    function D(t, n) {
        return t < n ? -1 : t > n ? 1 : t >= n ? 0 : NaN
    }
    function N(t) {
        return function() {
            this.removeAttribute(t)
        }
    }
    function U(t) {
        return function() {
            this.removeAttributeNS(t.space, t.local)
        }
    }
    function j(t, n) {
        return function() {
            this.setAttribute(t, n)
        }
    }
    function O(t, n) {
        return function() {
            this.setAttributeNS(t.space, t.local, n)
        }
    }
    function P(t, n) {
        return function() {
            var e = n.apply(this, arguments);
            null == e ? this.removeAttribute(t) : this.setAttribute(t, e)
        }
    }
    function H(t, n) {
        return function() {
            var e = n.apply(this, arguments);
            null == e ? this.removeAttributeNS(t.space, t.local) : this.setAttributeNS(t.space, t.local, e)
        }
    }
    function F(t) {
        return t.ownerDocument && t.ownerDocument.defaultView || t.document && t || t.defaultView
    }
    function Y(t) {
        return function() {
            this.style.removeProperty(t)
        }
    }
    function I(t, n, e) {
        return function() {
            this.style.setProperty(t, n, e)
        }
    }
    function L(t, n, e) {
        return function() {
            var r = n.apply(this, arguments);
            null == r ? this.style.removeProperty(t) : this.style.setProperty(t, r, e)
        }
    }
    function q(t, n) {
        return t.style.getPropertyValue(n) || F(t).getComputedStyle(t, null).getPropertyValue(n)
    }
    function X(t) {
        return function() {
            delete this[t]
        }
    }
    function V(t, n) {
        return function() {
            this[t] = n
        }
    }
    function R(t, n) {
        return function() {
            var e = n.apply(this, arguments);
            null == e ? delete this[t] : this[t] = e
        }
    }
    function B(t) {
        return t.trim().split(/^|\s+/)
    }
    function Z(t) {
        return t.classList || new W(t)
    }
    function W(t) {
        this._node = t,
        this._names = B(t.getAttribute("class") || "")
    }
    function G(t, n) {
        for (var e = Z(t), r = -1, i = n.length; ++r < i; )
            e.add(n[r])
    }
    function Q(t, n) {
        for (var e = Z(t), r = -1, i = n.length; ++r < i; )
            e.remove(n[r])
    }
    function J(t) {
        return function() {
            G(this, t)
        }
    }
    function K(t) {
        return function() {
            Q(this, t)
        }
    }
    function tt(t, n) {
        return function() {
            (n.apply(this, arguments) ? G : Q)(this, t)
        }
    }
    function nt() {
        this.textContent = ""
    }
    function et(t) {
        return function() {
            this.textContent = t
        }
    }
    function rt(t) {
        return function() {
            var n = t.apply(this, arguments);
            this.textContent = null == n ? "" : n
        }
    }
    function it() {
        this.innerHTML = ""
    }
    function ot(t) {
        return function() {
            this.innerHTML = t
        }
    }
    function at(t) {
        return function() {
            var n = t.apply(this, arguments);
            this.innerHTML = null == n ? "" : n
        }
    }
    function ut() {
        this.nextSibling && this.parentNode.appendChild(this)
    }
    function lt() {
        this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild)
    }
    function st() {
        return null
    }
    function ct() {
        var t = this.parentNode;
        t && t.removeChild(this)
    }
    function ft() {
        var t = this.cloneNode(!1)
          , n = this.parentNode;
        return n ? n.insertBefore(t, this.nextSibling) : t
    }
    function ht() {
        var t = this.cloneNode(!0)
          , n = this.parentNode;
        return n ? n.insertBefore(t, this.nextSibling) : t
    }
    function pt(t) {
        return function() {
            var n = this.__on;
            if (n) {
                for (var e, r = 0, i = -1, o = n.length; r < o; ++r)
                    e = n[r],
                    t.type && e.type !== t.type || e.name !== t.name ? n[++i] = e : this.removeEventListener(e.type, e.listener, e.options);
                ++i ? n.length = i : delete this.__on
            }
        }
    }
    function dt(t, n, e) {
        return function() {
            var r, i = this.__on, o = function(t) {
                return function(n) {
                    t.call(this, n, this.__data__)
                }
            }(n);
            if (i)
                for (var a = 0, u = i.length; a < u; ++a)
                    if ((r = i[a]).type === t.type && r.name === t.name)
                        return this.removeEventListener(r.type, r.listener, r.options),
                        this.addEventListener(r.type, r.listener = o, r.options = e),
                        void (r.value = n);
            this.addEventListener(t.type, o, e),
            r = {
                type: t.type,
                name: t.name,
                value: n,
                listener: o,
                options: e
            },
            i ? i.push(r) : this.__on = [r]
        }
    }
    function yt(t, n, e) {
        var r = F(t)
          , i = r.CustomEvent;
        "function" == typeof i ? i = new i(n,e) : (i = r.document.createEvent("Event"),
        e ? (i.initEvent(n, e.bubbles, e.cancelable),
        i.detail = e.detail) : i.initEvent(n, !1, !1)),
        t.dispatchEvent(i)
    }
    function gt(t, n) {
        return function() {
            return yt(this, t, n)
        }
    }
    function vt(t, n) {
        return function() {
            return yt(this, t, n.apply(this, arguments))
        }
    }
    A.prototype = {
        constructor: A,
        appendChild: function(t) {
            return this._parent.insertBefore(t, this._next)
        },
        insertBefore: function(t, n) {
            return this._parent.insertBefore(t, n)
        },
        querySelector: function(t) {
            return this._parent.querySelector(t)
        },
        querySelectorAll: function(t) {
            return this._parent.querySelectorAll(t)
        }
    },
    W.prototype = {
        add: function(t) {
            this._names.indexOf(t) < 0 && (this._names.push(t),
            this._node.setAttribute("class", this._names.join(" ")))
        },
        remove: function(t) {
            var n = this._names.indexOf(t);
            n >= 0 && (this._names.splice(n, 1),
            this._node.setAttribute("class", this._names.join(" ")))
        },
        contains: function(t) {
            return this._names.indexOf(t) >= 0
        }
    };
    var mt = [null];
    function _t(t, n) {
        this._groups = t,
        this._parents = n
    }
    function wt() {
        return new _t([[document.documentElement]],mt)
    }
    function bt(t) {
        return "string" == typeof t ? new _t([[document.querySelector(t)]],[document.documentElement]) : new _t([[t]],mt)
    }
    function xt(t, n) {
        if (t = function(t) {
            let n;
            for (; n = t.sourceEvent; )
                t = n;
            return t
        }(t),
        void 0 === n && (n = t.currentTarget),
        n) {
            var e = n.ownerSVGElement || n;
            if (e.createSVGPoint) {
                var r = e.createSVGPoint();
                return r.x = t.clientX,
                r.y = t.clientY,
                [(r = r.matrixTransform(n.getScreenCTM().inverse())).x, r.y]
            }
            if (n.getBoundingClientRect) {
                var i = n.getBoundingClientRect();
                return [t.clientX - i.left - n.clientLeft, t.clientY - i.top - n.clientTop]
            }
        }
        return [t.pageX, t.pageY]
    }
    _t.prototype = wt.prototype = {
        constructor: _t,
        select: function(t) {
            "function" != typeof t && (t = g(t));
            for (var n = this._groups, e = n.length, r = new Array(e), i = 0; i < e; ++i)
                for (var o, a, u = n[i], l = u.length, s = r[i] = new Array(l), c = 0; c < l; ++c)
                    (o = u[c]) && (a = t.call(o, o.__data__, c, u)) && ("__data__"in o && (a.__data__ = o.__data__),
                    s[c] = a);
            return new _t(r,this._parents)
        },
        selectAll: function(t) {
            t = "function" == typeof t ? _(t) : m(t);
            for (var n = this._groups, e = n.length, r = [], i = [], o = 0; o < e; ++o)
                for (var a, u = n[o], l = u.length, s = 0; s < l; ++s)
                    (a = u[s]) && (r.push(t.call(a, a.__data__, s, u)),
                    i.push(a));
            return new _t(r,i)
        },
        selectChild: function(t) {
            return this.select(null == t ? M : function(t) {
                return function() {
                    return x.call(this.children, t)
                }
            }("function" == typeof t ? t : b(t)))
        },
        selectChildren: function(t) {
            return this.selectAll(null == t ? C : function(t) {
                return function() {
                    return S.call(this.children, t)
                }
            }("function" == typeof t ? t : b(t)))
        },
        filter: function(t) {
            "function" != typeof t && (t = w(t));
            for (var n = this._groups, e = n.length, r = new Array(e), i = 0; i < e; ++i)
                for (var o, a = n[i], u = a.length, l = r[i] = [], s = 0; s < u; ++s)
                    (o = a[s]) && t.call(o, o.__data__, s, a) && l.push(o);
            return new _t(r,this._parents)
        },
        data: function(t, n) {
            if (!arguments.length)
                return Array.from(this, z);
            var e = n ? E : k
              , r = this._parents
              , i = this._groups;
            "function" != typeof t && (t = function(t) {
                return function() {
                    return t
                }
            }(t));
            for (var o = i.length, a = new Array(o), u = new Array(o), l = new Array(o), s = 0; s < o; ++s) {
                var c = r[s]
                  , f = i[s]
                  , h = f.length
                  , p = $(t.call(c, c && c.__data__, s, r))
                  , d = p.length
                  , y = u[s] = new Array(d)
                  , g = a[s] = new Array(d);
                e(c, f, y, g, l[s] = new Array(h), p, n);
                for (var v, m, _ = 0, w = 0; _ < d; ++_)
                    if (v = y[_]) {
                        for (_ >= w && (w = _ + 1); !(m = g[w]) && ++w < d; )
                            ;
                        v._next = m || null
                    }
            }
            return (a = new _t(a,r))._enter = u,
            a._exit = l,
            a
        },
        enter: function() {
            return new _t(this._enter || this._groups.map(T),this._parents)
        },
        exit: function() {
            return new _t(this._exit || this._groups.map(T),this._parents)
        },
        join: function(t, n, e) {
            var r = this.enter()
              , i = this
              , o = this.exit();
            return "function" == typeof t ? (r = t(r)) && (r = r.selection()) : r = r.append(t + ""),
            null != n && (i = n(i)) && (i = i.selection()),
            null == e ? o.remove() : e(o),
            r && i ? r.merge(i).order() : i
        },
        merge: function(t) {
            for (var n = t.selection ? t.selection() : t, e = this._groups, r = n._groups, i = e.length, o = r.length, a = Math.min(i, o), u = new Array(i), l = 0; l < a; ++l)
                for (var s, c = e[l], f = r[l], h = c.length, p = u[l] = new Array(h), d = 0; d < h; ++d)
                    (s = c[d] || f[d]) && (p[d] = s);
            for (; l < i; ++l)
                u[l] = e[l];
            return new _t(u,this._parents)
        },
        selection: function() {
            return this
        },
        order: function() {
            for (var t = this._groups, n = -1, e = t.length; ++n < e; )
                for (var r, i = t[n], o = i.length - 1, a = i[o]; --o >= 0; )
                    (r = i[o]) && (a && 4 ^ r.compareDocumentPosition(a) && a.parentNode.insertBefore(r, a),
                    a = r);
            return this
        },
        sort: function(t) {
            function n(n, e) {
                return n && e ? t(n.__data__, e.__data__) : !n - !e
            }
            t || (t = D);
            for (var e = this._groups, r = e.length, i = new Array(r), o = 0; o < r; ++o) {
                for (var a, u = e[o], l = u.length, s = i[o] = new Array(l), c = 0; c < l; ++c)
                    (a = u[c]) && (s[c] = a);
                s.sort(n)
            }
            return new _t(i,this._parents).order()
        },
        call: function() {
            var t = arguments[0];
            return arguments[0] = this,
            t.apply(null, arguments),
            this
        },
        nodes: function() {
            return Array.from(this)
        },
        node: function() {
            for (var t = this._groups, n = 0, e = t.length; n < e; ++n)
                for (var r = t[n], i = 0, o = r.length; i < o; ++i) {
                    var a = r[i];
                    if (a)
                        return a
                }
            return null
        },
        size: function() {
            let t = 0;
            for (const n of this)
                ++t;
            return t
        },
        empty: function() {
            return !this.node()
        },
        each: function(t) {
            for (var n = this._groups, e = 0, r = n.length; e < r; ++e)
                for (var i, o = n[e], a = 0, u = o.length; a < u; ++a)
                    (i = o[a]) && t.call(i, i.__data__, a, o);
            return this
        },
        attr: function(t, n) {
            var e = f(t);
            if (arguments.length < 2) {
                var r = this.node();
                return e.local ? r.getAttributeNS(e.space, e.local) : r.getAttribute(e)
            }
            return this.each((null == n ? e.local ? U : N : "function" == typeof n ? e.local ? H : P : e.local ? O : j)(e, n))
        },
        style: function(t, n, e) {
            return arguments.length > 1 ? this.each((null == n ? Y : "function" == typeof n ? L : I)(t, n, null == e ? "" : e)) : q(this.node(), t)
        },
        property: function(t, n) {
            return arguments.length > 1 ? this.each((null == n ? X : "function" == typeof n ? R : V)(t, n)) : this.node()[t]
        },
        classed: function(t, n) {
            var e = B(t + "");
            if (arguments.length < 2) {
                for (var r = Z(this.node()), i = -1, o = e.length; ++i < o; )
                    if (!r.contains(e[i]))
                        return !1;
                return !0
            }
            return this.each(("function" == typeof n ? tt : n ? J : K)(e, n))
        },
        text: function(t) {
            return arguments.length ? this.each(null == t ? nt : ("function" == typeof t ? rt : et)(t)) : this.node().textContent
        },
        html: function(t) {
            return arguments.length ? this.each(null == t ? it : ("function" == typeof t ? at : ot)(t)) : this.node().innerHTML
        },
        raise: function() {
            return this.each(ut)
        },
        lower: function() {
            return this.each(lt)
        },
        append: function(t) {
            var n = "function" == typeof t ? t : d(t);
            return this.select((function() {
                return this.appendChild(n.apply(this, arguments))
            }
            ))
        },
        insert: function(t, n) {
            var e = "function" == typeof t ? t : d(t)
              , r = null == n ? st : "function" == typeof n ? n : g(n);
            return this.select((function() {
                return this.insertBefore(e.apply(this, arguments), r.apply(this, arguments) || null)
            }
            ))
        },
        remove: function() {
            return this.each(ct)
        },
        clone: function(t) {
            return this.select(t ? ht : ft)
        },
        datum: function(t) {
            return arguments.length ? this.property("__data__", t) : this.node().__data__
        },
        on: function(t, n, e) {
            var r, i, o = function(t) {
                return t.trim().split(/^|\s+/).map((function(t) {
                    var n = ""
                      , e = t.indexOf(".");
                    return e >= 0 && (n = t.slice(e + 1),
                    t = t.slice(0, e)),
                    {
                        type: t,
                        name: n
                    }
                }
                ))
            }(t + ""), a = o.length;
            if (!(arguments.length < 2)) {
                for (u = n ? dt : pt,
                r = 0; r < a; ++r)
                    this.each(u(o[r], n, e));
                return this
            }
            var u = this.node().__on;
            if (u)
                for (var l, s = 0, c = u.length; s < c; ++s)
                    for (r = 0,
                    l = u[s]; r < a; ++r)
                        if ((i = o[r]).type === l.type && i.name === l.name)
                            return l.value
        },
        dispatch: function(t, n) {
            return this.each(("function" == typeof n ? vt : gt)(t, n))
        },
        [Symbol.iterator]: function*() {
            for (var t = this._groups, n = 0, e = t.length; n < e; ++n)
                for (var r, i = t[n], o = 0, a = i.length; o < a; ++o)
                    (r = i[o]) && (yield r)
        }
    };
    var Mt = {
        value: () => {}
    };
    function St() {
        for (var t, n = 0, e = arguments.length, r = {}; n < e; ++n) {
            if (!(t = arguments[n] + "") || t in r || /[\s.]/.test(t))
                throw new Error("illegal type: " + t);
            r[t] = []
        }
        return new Ct(r)
    }
    function Ct(t) {
        this._ = t
    }
    function Tt(t, n) {
        for (var e, r = 0, i = t.length; r < i; ++r)
            if ((e = t[r]).name === n)
                return e.value
    }
    function At(t, n, e) {
        for (var r = 0, i = t.length; r < i; ++r)
            if (t[r].name === n) {
                t[r] = Mt,
                t = t.slice(0, r).concat(t.slice(r + 1));
                break
            }
        return null != e && t.push({
            name: n,
            value: e
        }),
        t
    }
    Ct.prototype = St.prototype = {
        constructor: Ct,
        on: function(t, n) {
            var e, r, i = this._, o = (r = i,
            (t + "").trim().split(/^|\s+/).map((function(t) {
                var n = ""
                  , e = t.indexOf(".");
                if (e >= 0 && (n = t.slice(e + 1),
                t = t.slice(0, e)),
                t && !r.hasOwnProperty(t))
                    throw new Error("unknown type: " + t);
                return {
                    type: t,
                    name: n
                }
            }
            ))), a = -1, u = o.length;
            if (!(arguments.length < 2)) {
                if (null != n && "function" != typeof n)
                    throw new Error("invalid callback: " + n);
                for (; ++a < u; )
                    if (e = (t = o[a]).type)
                        i[e] = At(i[e], t.name, n);
                    else if (null == n)
                        for (e in i)
                            i[e] = At(i[e], t.name, null);
                return this
            }
            for (; ++a < u; )
                if ((e = (t = o[a]).type) && (e = Tt(i[e], t.name)))
                    return e
        },
        copy: function() {
            var t = {}
              , n = this._;
            for (var e in n)
                t[e] = n[e].slice();
            return new Ct(t)
        },
        call: function(t, n) {
            if ((e = arguments.length - 2) > 0)
                for (var e, r, i = new Array(e), o = 0; o < e; ++o)
                    i[o] = arguments[o + 2];
            if (!this._.hasOwnProperty(t))
                throw new Error("unknown type: " + t);
            for (o = 0,
            e = (r = this._[t]).length; o < e; ++o)
                r[o].value.apply(n, i)
        },
        apply: function(t, n, e) {
            if (!this._.hasOwnProperty(t))
                throw new Error("unknown type: " + t);
            for (var r = this._[t], i = 0, o = r.length; i < o; ++i)
                r[i].value.apply(n, e)
        }
    };
    var kt, Et, zt = 0, $t = 0, Dt = 0, Nt = 1e3, Ut = 0, jt = 0, Ot = 0, Pt = "object" == typeof performance && performance.now ? performance : Date, Ht = "object" == typeof window && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(t) {
        setTimeout(t, 17)
    }
    ;
    function Ft() {
        return jt || (Ht(Yt),
        jt = Pt.now() + Ot)
    }
    function Yt() {
        jt = 0
    }
    function It() {
        this._call = this._time = this._next = null
    }
    function Lt(t, n, e) {
        var r = new It;
        return r.restart(t, n, e),
        r
    }
    function qt() {
        jt = (Ut = Pt.now()) + Ot,
        zt = $t = 0;
        try {
            !function() {
                Ft(),
                ++zt;
                for (var t, n = kt; n; )
                    (t = jt - n._time) >= 0 && n._call.call(void 0, t),
                    n = n._next;
                --zt
            }()
        } finally {
            zt = 0,
            function() {
                var t, n, e = kt, r = 1 / 0;
                for (; e; )
                    e._call ? (r > e._time && (r = e._time),
                    t = e,
                    e = e._next) : (n = e._next,
                    e._next = null,
                    e = t ? t._next = n : kt = n);
                Et = t,
                Vt(r)
            }(),
            jt = 0
        }
    }
    function Xt() {
        var t = Pt.now()
          , n = t - Ut;
        n > Nt && (Ot -= n,
        Ut = t)
    }
    function Vt(t) {
        zt || ($t && ($t = clearTimeout($t)),
        t - jt > 24 ? (t < 1 / 0 && ($t = setTimeout(qt, t - Pt.now() - Ot)),
        Dt && (Dt = clearInterval(Dt))) : (Dt || (Ut = Pt.now(),
        Dt = setInterval(Xt, Nt)),
        zt = 1,
        Ht(qt)))
    }
    function Rt(t, n, e) {
        var r = new It;
        return n = null == n ? 0 : +n,
        r.restart((e => {
            r.stop(),
            t(e + n)
        }
        ), n, e),
        r
    }
    It.prototype = Lt.prototype = {
        constructor: It,
        restart: function(t, n, e) {
            if ("function" != typeof t)
                throw new TypeError("callback is not a function");
            e = (null == e ? Ft() : +e) + (null == n ? 0 : +n),
            this._next || Et === this || (Et ? Et._next = this : kt = this,
            Et = this),
            this._call = t,
            this._time = e,
            Vt()
        },
        stop: function() {
            this._call && (this._call = null,
            this._time = 1 / 0,
            Vt())
        }
    };
    var Bt = St("start", "end", "cancel", "interrupt")
      , Zt = []
      , Wt = 0
      , Gt = 1
      , Qt = 2
      , Jt = 3
      , Kt = 4
      , tn = 5
      , nn = 6;
    function en(t, n, e, r, i, o) {
        var a = t.__transition;
        if (a) {
            if (e in a)
                return
        } else
            t.__transition = {};
        !function(t, n, e) {
            var r, i = t.__transition;
            function o(t) {
                e.state = Gt,
                e.timer.restart(a, e.delay, e.time),
                e.delay <= t && a(t - e.delay)
            }
            function a(o) {
                var s, c, f, h;
                if (e.state !== Gt)
                    return l();
                for (s in i)
                    if ((h = i[s]).name === e.name) {
                        if (h.state === Jt)
                            return Rt(a);
                        h.state === Kt ? (h.state = nn,
                        h.timer.stop(),
                        h.on.call("interrupt", t, t.__data__, h.index, h.group),
                        delete i[s]) : +s < n && (h.state = nn,
                        h.timer.stop(),
                        h.on.call("cancel", t, t.__data__, h.index, h.group),
                        delete i[s])
                    }
                if (Rt((function() {
                    e.state === Jt && (e.state = Kt,
                    e.timer.restart(u, e.delay, e.time),
                    u(o))
                }
                )),
                e.state = Qt,
                e.on.call("start", t, t.__data__, e.index, e.group),
                e.state === Qt) {
                    for (e.state = Jt,
                    r = new Array(f = e.tween.length),
                    s = 0,
                    c = -1; s < f; ++s)
                        (h = e.tween[s].value.call(t, t.__data__, e.index, e.group)) && (r[++c] = h);
                    r.length = c + 1
                }
            }
            function u(n) {
                for (var i = n < e.duration ? e.ease.call(null, n / e.duration) : (e.timer.restart(l),
                e.state = tn,
                1), o = -1, a = r.length; ++o < a; )
                    r[o].call(t, i);
                e.state === tn && (e.on.call("end", t, t.__data__, e.index, e.group),
                l())
            }
            function l() {
                for (var r in e.state = nn,
                e.timer.stop(),
                delete i[n],
                i)
                    return;
                delete t.__transition
            }
            i[n] = e,
            e.timer = Lt(o, 0, e.time)
        }(t, e, {
            name: n,
            index: r,
            group: i,
            on: Bt,
            tween: Zt,
            time: o.time,
            delay: o.delay,
            duration: o.duration,
            ease: o.ease,
            timer: null,
            state: Wt
        })
    }
    function rn(t, n) {
        var e = an(t, n);
        if (e.state > Wt)
            throw new Error("too late; already scheduled");
        return e
    }
    function on(t, n) {
        var e = an(t, n);
        if (e.state > Jt)
            throw new Error("too late; already running");
        return e
    }
    function an(t, n) {
        var e = t.__transition;
        if (!e || !(e = e[n]))
            throw new Error("transition not found");
        return e
    }
    function un(t, n) {
        var e, r, i, o = t.__transition, a = !0;
        if (o) {
            for (i in n = null == n ? null : n + "",
            o)
                (e = o[i]).name === n ? (r = e.state > Qt && e.state < tn,
                e.state = nn,
                e.timer.stop(),
                e.on.call(r ? "interrupt" : "cancel", t, t.__data__, e.index, e.group),
                delete o[i]) : a = !1;
            a && delete t.__transition
        }
    }
    function ln(t, n, e) {
        t.prototype = n.prototype = e,
        e.constructor = t
    }
    function sn(t, n) {
        var e = Object.create(t.prototype);
        for (var r in n)
            e[r] = n[r];
        return e
    }
    function cn() {}
    var fn = .7
      , hn = 1 / fn
      , pn = "\\s*([+-]?\\d+)\\s*"
      , dn = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*"
      , yn = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*"
      , gn = /^#([0-9a-f]{3,8})$/
      , vn = new RegExp(`^rgb\\(${pn},${pn},${pn}\\)$`)
      , mn = new RegExp(`^rgb\\(${yn},${yn},${yn}\\)$`)
      , _n = new RegExp(`^rgba\\(${pn},${pn},${pn},${dn}\\)$`)
      , wn = new RegExp(`^rgba\\(${yn},${yn},${yn},${dn}\\)$`)
      , bn = new RegExp(`^hsl\\(${dn},${yn},${yn}\\)$`)
      , xn = new RegExp(`^hsla\\(${dn},${yn},${yn},${dn}\\)$`)
      , Mn = {
        aliceblue: 15792383,
        antiquewhite: 16444375,
        aqua: 65535,
        aquamarine: 8388564,
        azure: 15794175,
        beige: 16119260,
        bisque: 16770244,
        black: 0,
        blanchedalmond: 16772045,
        blue: 255,
        blueviolet: 9055202,
        brown: 10824234,
        burlywood: 14596231,
        cadetblue: 6266528,
        chartreuse: 8388352,
        chocolate: 13789470,
        coral: 16744272,
        cornflowerblue: 6591981,
        cornsilk: 16775388,
        crimson: 14423100,
        cyan: 65535,
        darkblue: 139,
        darkcyan: 35723,
        darkgoldenrod: 12092939,
        darkgray: 11119017,
        darkgreen: 25600,
        darkgrey: 11119017,
        darkkhaki: 12433259,
        darkmagenta: 9109643,
        darkolivegreen: 5597999,
        darkorange: 16747520,
        darkorchid: 10040012,
        darkred: 9109504,
        darksalmon: 15308410,
        darkseagreen: 9419919,
        darkslateblue: 4734347,
        darkslategray: 3100495,
        darkslategrey: 3100495,
        darkturquoise: 52945,
        darkviolet: 9699539,
        deeppink: 16716947,
        deepskyblue: 49151,
        dimgray: 6908265,
        dimgrey: 6908265,
        dodgerblue: 2003199,
        firebrick: 11674146,
        floralwhite: 16775920,
        forestgreen: 2263842,
        fuchsia: 16711935,
        gainsboro: 14474460,
        ghostwhite: 16316671,
        gold: 16766720,
        goldenrod: 14329120,
        gray: 8421504,
        green: 32768,
        greenyellow: 11403055,
        grey: 8421504,
        honeydew: 15794160,
        hotpink: 16738740,
        indianred: 13458524,
        indigo: 4915330,
        ivory: 16777200,
        khaki: 15787660,
        lavender: 15132410,
        lavenderblush: 16773365,
        lawngreen: 8190976,
        lemonchiffon: 16775885,
        lightblue: 11393254,
        lightcoral: 15761536,
        lightcyan: 14745599,
        lightgoldenrodyellow: 16448210,
        lightgray: 13882323,
        lightgreen: 9498256,
        lightgrey: 13882323,
        lightpink: 16758465,
        lightsalmon: 16752762,
        lightseagreen: 2142890,
        lightskyblue: 8900346,
        lightslategray: 7833753,
        lightslategrey: 7833753,
        lightsteelblue: 11584734,
        lightyellow: 16777184,
        lime: 65280,
        limegreen: 3329330,
        linen: 16445670,
        magenta: 16711935,
        maroon: 8388608,
        mediumaquamarine: 6737322,
        mediumblue: 205,
        mediumorchid: 12211667,
        mediumpurple: 9662683,
        mediumseagreen: 3978097,
        mediumslateblue: 8087790,
        mediumspringgreen: 64154,
        mediumturquoise: 4772300,
        mediumvioletred: 13047173,
        midnightblue: 1644912,
        mintcream: 16121850,
        mistyrose: 16770273,
        moccasin: 16770229,
        navajowhite: 16768685,
        navy: 128,
        oldlace: 16643558,
        olive: 8421376,
        olivedrab: 7048739,
        orange: 16753920,
        orangered: 16729344,
        orchid: 14315734,
        palegoldenrod: 15657130,
        palegreen: 10025880,
        paleturquoise: 11529966,
        palevioletred: 14381203,
        papayawhip: 16773077,
        peachpuff: 16767673,
        peru: 13468991,
        pink: 16761035,
        plum: 14524637,
        powderblue: 11591910,
        purple: 8388736,
        rebeccapurple: 6697881,
        red: 16711680,
        rosybrown: 12357519,
        royalblue: 4286945,
        saddlebrown: 9127187,
        salmon: 16416882,
        sandybrown: 16032864,
        seagreen: 3050327,
        seashell: 16774638,
        sienna: 10506797,
        silver: 12632256,
        skyblue: 8900331,
        slateblue: 6970061,
        slategray: 7372944,
        slategrey: 7372944,
        snow: 16775930,
        springgreen: 65407,
        steelblue: 4620980,
        tan: 13808780,
        teal: 32896,
        thistle: 14204888,
        tomato: 16737095,
        turquoise: 4251856,
        violet: 15631086,
        wheat: 16113331,
        white: 16777215,
        whitesmoke: 16119285,
        yellow: 16776960,
        yellowgreen: 10145074
    };
    function Sn() {
        return this.rgb().formatHex()
    }
    function Cn() {
        return this.rgb().formatRgb()
    }
    function Tn(t) {
        var n, e;
        return t = (t + "").trim().toLowerCase(),
        (n = gn.exec(t)) ? (e = n[1].length,
        n = parseInt(n[1], 16),
        6 === e ? An(n) : 3 === e ? new zn(n >> 8 & 15 | n >> 4 & 240,n >> 4 & 15 | 240 & n,(15 & n) << 4 | 15 & n,1) : 8 === e ? kn(n >> 24 & 255, n >> 16 & 255, n >> 8 & 255, (255 & n) / 255) : 4 === e ? kn(n >> 12 & 15 | n >> 8 & 240, n >> 8 & 15 | n >> 4 & 240, n >> 4 & 15 | 240 & n, ((15 & n) << 4 | 15 & n) / 255) : null) : (n = vn.exec(t)) ? new zn(n[1],n[2],n[3],1) : (n = mn.exec(t)) ? new zn(255 * n[1] / 100,255 * n[2] / 100,255 * n[3] / 100,1) : (n = _n.exec(t)) ? kn(n[1], n[2], n[3], n[4]) : (n = wn.exec(t)) ? kn(255 * n[1] / 100, 255 * n[2] / 100, 255 * n[3] / 100, n[4]) : (n = bn.exec(t)) ? On(n[1], n[2] / 100, n[3] / 100, 1) : (n = xn.exec(t)) ? On(n[1], n[2] / 100, n[3] / 100, n[4]) : Mn.hasOwnProperty(t) ? An(Mn[t]) : "transparent" === t ? new zn(NaN,NaN,NaN,0) : null
    }
    function An(t) {
        return new zn(t >> 16 & 255,t >> 8 & 255,255 & t,1)
    }
    function kn(t, n, e, r) {
        return r <= 0 && (t = n = e = NaN),
        new zn(t,n,e,r)
    }
    function En(t, n, e, r) {
        return 1 === arguments.length ? ((i = t)instanceof cn || (i = Tn(i)),
        i ? new zn((i = i.rgb()).r,i.g,i.b,i.opacity) : new zn) : new zn(t,n,e,null == r ? 1 : r);
        var i
    }
    function zn(t, n, e, r) {
        this.r = +t,
        this.g = +n,
        this.b = +e,
        this.opacity = +r
    }
    function $n() {
        return `#${jn(this.r)}${jn(this.g)}${jn(this.b)}`
    }
    function Dn() {
        const t = Nn(this.opacity);
        return `${1 === t ? "rgb(" : "rgba("}${Un(this.r)}, ${Un(this.g)}, ${Un(this.b)}${1 === t ? ")" : `, ${t})`}`
    }
    function Nn(t) {
        return isNaN(t) ? 1 : Math.max(0, Math.min(1, t))
    }
    function Un(t) {
        return Math.max(0, Math.min(255, Math.round(t) || 0))
    }
    function jn(t) {
        return ((t = Un(t)) < 16 ? "0" : "") + t.toString(16)
    }
    function On(t, n, e, r) {
        return r <= 0 ? t = n = e = NaN : e <= 0 || e >= 1 ? t = n = NaN : n <= 0 && (t = NaN),
        new Hn(t,n,e,r)
    }
    function Pn(t) {
        if (t instanceof Hn)
            return new Hn(t.h,t.s,t.l,t.opacity);
        if (t instanceof cn || (t = Tn(t)),
        !t)
            return new Hn;
        if (t instanceof Hn)
            return t;
        var n = (t = t.rgb()).r / 255
          , e = t.g / 255
          , r = t.b / 255
          , i = Math.min(n, e, r)
          , o = Math.max(n, e, r)
          , a = NaN
          , u = o - i
          , l = (o + i) / 2;
        return u ? (a = n === o ? (e - r) / u + 6 * (e < r) : e === o ? (r - n) / u + 2 : (n - e) / u + 4,
        u /= l < .5 ? o + i : 2 - o - i,
        a *= 60) : u = l > 0 && l < 1 ? 0 : a,
        new Hn(a,u,l,t.opacity)
    }
    function Hn(t, n, e, r) {
        this.h = +t,
        this.s = +n,
        this.l = +e,
        this.opacity = +r
    }
    function Fn(t) {
        return (t = (t || 0) % 360) < 0 ? t + 360 : t
    }
    function Yn(t) {
        return Math.max(0, Math.min(1, t || 0))
    }
    function In(t, n, e) {
        return 255 * (t < 60 ? n + (e - n) * t / 60 : t < 180 ? e : t < 240 ? n + (e - n) * (240 - t) / 60 : n)
    }
    ln(cn, Tn, {
        copy(t) {
            return Object.assign(new this.constructor, this, t)
        },
        displayable() {
            return this.rgb().displayable()
        },
        hex: Sn,
        formatHex: Sn,
        formatHex8: function() {
            return this.rgb().formatHex8()
        },
        formatHsl: function() {
            return Pn(this).formatHsl()
        },
        formatRgb: Cn,
        toString: Cn
    }),
    ln(zn, En, sn(cn, {
        brighter(t) {
            return t = null == t ? hn : Math.pow(hn, t),
            new zn(this.r * t,this.g * t,this.b * t,this.opacity)
        },
        darker(t) {
            return t = null == t ? fn : Math.pow(fn, t),
            new zn(this.r * t,this.g * t,this.b * t,this.opacity)
        },
        rgb() {
            return this
        },
        clamp() {
            return new zn(Un(this.r),Un(this.g),Un(this.b),Nn(this.opacity))
        },
        displayable() {
            return -.5 <= this.r && this.r < 255.5 && -.5 <= this.g && this.g < 255.5 && -.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1
        },
        hex: $n,
        formatHex: $n,
        formatHex8: function() {
            return `#${jn(this.r)}${jn(this.g)}${jn(this.b)}${jn(255 * (isNaN(this.opacity) ? 1 : this.opacity))}`
        },
        formatRgb: Dn,
        toString: Dn
    })),
    ln(Hn, (function(t, n, e, r) {
        return 1 === arguments.length ? Pn(t) : new Hn(t,n,e,null == r ? 1 : r)
    }
    ), sn(cn, {
        brighter(t) {
            return t = null == t ? hn : Math.pow(hn, t),
            new Hn(this.h,this.s,this.l * t,this.opacity)
        },
        darker(t) {
            return t = null == t ? fn : Math.pow(fn, t),
            new Hn(this.h,this.s,this.l * t,this.opacity)
        },
        rgb() {
            var t = this.h % 360 + 360 * (this.h < 0)
              , n = isNaN(t) || isNaN(this.s) ? 0 : this.s
              , e = this.l
              , r = e + (e < .5 ? e : 1 - e) * n
              , i = 2 * e - r;
            return new zn(In(t >= 240 ? t - 240 : t + 120, i, r),In(t, i, r),In(t < 120 ? t + 240 : t - 120, i, r),this.opacity)
        },
        clamp() {
            return new Hn(Fn(this.h),Yn(this.s),Yn(this.l),Nn(this.opacity))
        },
        displayable() {
            return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1
        },
        formatHsl() {
            const t = Nn(this.opacity);
            return `${1 === t ? "hsl(" : "hsla("}${Fn(this.h)}, ${100 * Yn(this.s)}%, ${100 * Yn(this.l)}%${1 === t ? ")" : `, ${t})`}`
        }
    }));
    var Ln = t => () => t;
    function qn(t) {
        return 1 == (t = +t) ? Xn : function(n, e) {
            return e - n ? function(t, n, e) {
                return t = Math.pow(t, e),
                n = Math.pow(n, e) - t,
                e = 1 / e,
                function(r) {
                    return Math.pow(t + r * n, e)
                }
            }(n, e, t) : Ln(isNaN(n) ? e : n)
        }
    }
    function Xn(t, n) {
        var e = n - t;
        return e ? function(t, n) {
            return function(e) {
                return t + e * n
            }
        }(t, e) : Ln(isNaN(t) ? n : t)
    }
    var Vn = function t(n) {
        var e = qn(n);
        function r(t, n) {
            var r = e((t = En(t)).r, (n = En(n)).r)
              , i = e(t.g, n.g)
              , o = e(t.b, n.b)
              , a = Xn(t.opacity, n.opacity);
            return function(n) {
                return t.r = r(n),
                t.g = i(n),
                t.b = o(n),
                t.opacity = a(n),
                t + ""
            }
        }
        return r.gamma = t,
        r
    }(1);
    function Rn(t, n) {
        n || (n = []);
        var e, r = t ? Math.min(n.length, t.length) : 0, i = n.slice();
        return function(o) {
            for (e = 0; e < r; ++e)
                i[e] = t[e] * (1 - o) + n[e] * o;
            return i
        }
    }
    function Bn(t, n) {
        var e, r = n ? n.length : 0, i = t ? Math.min(r, t.length) : 0, o = new Array(i), a = new Array(r);
        for (e = 0; e < i; ++e)
            o[e] = te(t[e], n[e]);
        for (; e < r; ++e)
            a[e] = n[e];
        return function(t) {
            for (e = 0; e < i; ++e)
                a[e] = o[e](t);
            return a
        }
    }
    function Zn(t, n) {
        var e = new Date;
        return t = +t,
        n = +n,
        function(r) {
            return e.setTime(t * (1 - r) + n * r),
            e
        }
    }
    function Wn(t, n) {
        return t = +t,
        n = +n,
        function(e) {
            return t * (1 - e) + n * e
        }
    }
    function Gn(t, n) {
        var e, r = {}, i = {};
        for (e in null !== t && "object" == typeof t || (t = {}),
        null !== n && "object" == typeof n || (n = {}),
        n)
            e in t ? r[e] = te(t[e], n[e]) : i[e] = n[e];
        return function(t) {
            for (e in r)
                i[e] = r[e](t);
            return i
        }
    }
    var Qn = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g
      , Jn = new RegExp(Qn.source,"g");
    function Kn(t, n) {
        var e, r, i, o = Qn.lastIndex = Jn.lastIndex = 0, a = -1, u = [], l = [];
        for (t += "",
        n += ""; (e = Qn.exec(t)) && (r = Jn.exec(n)); )
            (i = r.index) > o && (i = n.slice(o, i),
            u[a] ? u[a] += i : u[++a] = i),
            (e = e[0]) === (r = r[0]) ? u[a] ? u[a] += r : u[++a] = r : (u[++a] = null,
            l.push({
                i: a,
                x: Wn(e, r)
            })),
            o = Jn.lastIndex;
        return o < n.length && (i = n.slice(o),
        u[a] ? u[a] += i : u[++a] = i),
        u.length < 2 ? l[0] ? function(t) {
            return function(n) {
                return t(n) + ""
            }
        }(l[0].x) : function(t) {
            return function() {
                return t
            }
        }(n) : (n = l.length,
        function(t) {
            for (var e, r = 0; r < n; ++r)
                u[(e = l[r]).i] = e.x(t);
            return u.join("")
        }
        )
    }
    function te(t, n) {
        var e, r = typeof n;
        return null == n || "boolean" === r ? Ln(n) : ("number" === r ? Wn : "string" === r ? (e = Tn(n)) ? (n = e,
        Vn) : Kn : n instanceof Tn ? Vn : n instanceof Date ? Zn : function(t) {
            return ArrayBuffer.isView(t) && !(t instanceof DataView)
        }(n) ? Rn : Array.isArray(n) ? Bn : "function" != typeof n.valueOf && "function" != typeof n.toString || isNaN(n) ? Gn : Wn)(t, n)
    }
    function ne(t, n) {
        return t = +t,
        n = +n,
        function(e) {
            return Math.round(t * (1 - e) + n * e)
        }
    }
    var ee, re = 180 / Math.PI, ie = {
        translateX: 0,
        translateY: 0,
        rotate: 0,
        skewX: 0,
        scaleX: 1,
        scaleY: 1
    };
    function oe(t, n, e, r, i, o) {
        var a, u, l;
        return (a = Math.sqrt(t * t + n * n)) && (t /= a,
        n /= a),
        (l = t * e + n * r) && (e -= t * l,
        r -= n * l),
        (u = Math.sqrt(e * e + r * r)) && (e /= u,
        r /= u,
        l /= u),
        t * r < n * e && (t = -t,
        n = -n,
        l = -l,
        a = -a),
        {
            translateX: i,
            translateY: o,
            rotate: Math.atan2(n, t) * re,
            skewX: Math.atan(l) * re,
            scaleX: a,
            scaleY: u
        }
    }
    function ae(t, n, e, r) {
        function i(t) {
            return t.length ? t.pop() + " " : ""
        }
        return function(o, a) {
            var u = []
              , l = [];
            return o = t(o),
            a = t(a),
            function(t, r, i, o, a, u) {
                if (t !== i || r !== o) {
                    var l = a.push("translate(", null, n, null, e);
                    u.push({
                        i: l - 4,
                        x: Wn(t, i)
                    }, {
                        i: l - 2,
                        x: Wn(r, o)
                    })
                } else
                    (i || o) && a.push("translate(" + i + n + o + e)
            }(o.translateX, o.translateY, a.translateX, a.translateY, u, l),
            function(t, n, e, o) {
                t !== n ? (t - n > 180 ? n += 360 : n - t > 180 && (t += 360),
                o.push({
                    i: e.push(i(e) + "rotate(", null, r) - 2,
                    x: Wn(t, n)
                })) : n && e.push(i(e) + "rotate(" + n + r)
            }(o.rotate, a.rotate, u, l),
            function(t, n, e, o) {
                t !== n ? o.push({
                    i: e.push(i(e) + "skewX(", null, r) - 2,
                    x: Wn(t, n)
                }) : n && e.push(i(e) + "skewX(" + n + r)
            }(o.skewX, a.skewX, u, l),
            function(t, n, e, r, o, a) {
                if (t !== e || n !== r) {
                    var u = o.push(i(o) + "scale(", null, ",", null, ")");
                    a.push({
                        i: u - 4,
                        x: Wn(t, e)
                    }, {
                        i: u - 2,
                        x: Wn(n, r)
                    })
                } else
                    1 === e && 1 === r || o.push(i(o) + "scale(" + e + "," + r + ")")
            }(o.scaleX, o.scaleY, a.scaleX, a.scaleY, u, l),
            o = a = null,
            function(t) {
                for (var n, e = -1, r = l.length; ++e < r; )
                    u[(n = l[e]).i] = n.x(t);
                return u.join("")
            }
        }
    }
    var ue = ae((function(t) {
        const n = new ("function" == typeof DOMMatrix ? DOMMatrix : WebKitCSSMatrix)(t + "");
        return n.isIdentity ? ie : oe(n.a, n.b, n.c, n.d, n.e, n.f)
    }
    ), "px, ", "px)", "deg)")
      , le = ae((function(t) {
        return null == t ? ie : (ee || (ee = document.createElementNS("http://www.w3.org/2000/svg", "g")),
        ee.setAttribute("transform", t),
        (t = ee.transform.baseVal.consolidate()) ? oe((t = t.matrix).a, t.b, t.c, t.d, t.e, t.f) : ie)
    }
    ), ", ", ")", ")")
      , se = 1e-12;
    function ce(t) {
        return ((t = Math.exp(t)) + 1 / t) / 2
    }
    var fe = function t(n, e, r) {
        function i(t, i) {
            var o, a, u = t[0], l = t[1], s = t[2], c = i[0], f = i[1], h = i[2], p = c - u, d = f - l, y = p * p + d * d;
            if (y < se)
                a = Math.log(h / s) / n,
                o = function(t) {
                    return [u + t * p, l + t * d, s * Math.exp(n * t * a)]
                }
                ;
            else {
                var g = Math.sqrt(y)
                  , v = (h * h - s * s + r * y) / (2 * s * e * g)
                  , m = (h * h - s * s - r * y) / (2 * h * e * g)
                  , _ = Math.log(Math.sqrt(v * v + 1) - v)
                  , w = Math.log(Math.sqrt(m * m + 1) - m);
                a = (w - _) / n,
                o = function(t) {
                    var r = t * a
                      , i = ce(_)
                      , o = s / (e * g) * (i * function(t) {
                        return ((t = Math.exp(2 * t)) - 1) / (t + 1)
                    }(n * r + _) - function(t) {
                        return ((t = Math.exp(t)) - 1 / t) / 2
                    }(_));
                    return [u + o * p, l + o * d, s * i / ce(n * r + _)]
                }
            }
            return o.duration = 1e3 * a * n / Math.SQRT2,
            o
        }
        return i.rho = function(n) {
            var e = Math.max(.001, +n)
              , r = e * e;
            return t(e, r, r * r)
        }
        ,
        i
    }(Math.SQRT2, 2, 4);
    function he(t, n) {
        var e, r;
        return function() {
            var i = on(this, t)
              , o = i.tween;
            if (o !== e)
                for (var a = 0, u = (r = e = o).length; a < u; ++a)
                    if (r[a].name === n) {
                        (r = r.slice()).splice(a, 1);
                        break
                    }
            i.tween = r
        }
    }
    function pe(t, n, e) {
        var r, i;
        if ("function" != typeof e)
            throw new Error;
        return function() {
            var o = on(this, t)
              , a = o.tween;
            if (a !== r) {
                i = (r = a).slice();
                for (var u = {
                    name: n,
                    value: e
                }, l = 0, s = i.length; l < s; ++l)
                    if (i[l].name === n) {
                        i[l] = u;
                        break
                    }
                l === s && i.push(u)
            }
            o.tween = i
        }
    }
    function de(t, n, e) {
        var r = t._id;
        return t.each((function() {
            var t = on(this, r);
            (t.value || (t.value = {}))[n] = e.apply(this, arguments)
        }
        )),
        function(t) {
            return an(t, r).value[n]
        }
    }
    function ye(t, n) {
        var e;
        return ("number" == typeof n ? Wn : n instanceof Tn ? Vn : (e = Tn(n)) ? (n = e,
        Vn) : Kn)(t, n)
    }
    function ge(t) {
        return function() {
            this.removeAttribute(t)
        }
    }
    function ve(t) {
        return function() {
            this.removeAttributeNS(t.space, t.local)
        }
    }
    function me(t, n, e) {
        var r, i, o = e + "";
        return function() {
            var a = this.getAttribute(t);
            return a === o ? null : a === r ? i : i = n(r = a, e)
        }
    }
    function _e(t, n, e) {
        var r, i, o = e + "";
        return function() {
            var a = this.getAttributeNS(t.space, t.local);
            return a === o ? null : a === r ? i : i = n(r = a, e)
        }
    }
    function we(t, n, e) {
        var r, i, o;
        return function() {
            var a, u, l = e(this);
            if (null != l)
                return (a = this.getAttribute(t)) === (u = l + "") ? null : a === r && u === i ? o : (i = u,
                o = n(r = a, l));
            this.removeAttribute(t)
        }
    }
    function be(t, n, e) {
        var r, i, o;
        return function() {
            var a, u, l = e(this);
            if (null != l)
                return (a = this.getAttributeNS(t.space, t.local)) === (u = l + "") ? null : a === r && u === i ? o : (i = u,
                o = n(r = a, l));
            this.removeAttributeNS(t.space, t.local)
        }
    }
    function xe(t, n) {
        var e, r;
        function i() {
            var i = n.apply(this, arguments);
            return i !== r && (e = (r = i) && function(t, n) {
                return function(e) {
                    this.setAttributeNS(t.space, t.local, n.call(this, e))
                }
            }(t, i)),
            e
        }
        return i._value = n,
        i
    }
    function Me(t, n) {
        var e, r;
        function i() {
            var i = n.apply(this, arguments);
            return i !== r && (e = (r = i) && function(t, n) {
                return function(e) {
                    this.setAttribute(t, n.call(this, e))
                }
            }(t, i)),
            e
        }
        return i._value = n,
        i
    }
    function Se(t, n) {
        return function() {
            rn(this, t).delay = +n.apply(this, arguments)
        }
    }
    function Ce(t, n) {
        return n = +n,
        function() {
            rn(this, t).delay = n
        }
    }
    function Te(t, n) {
        return function() {
            on(this, t).duration = +n.apply(this, arguments)
        }
    }
    function Ae(t, n) {
        return n = +n,
        function() {
            on(this, t).duration = n
        }
    }
    var ke = wt.prototype.constructor;
    function Ee(t) {
        return function() {
            this.style.removeProperty(t)
        }
    }
    var ze = 0;
    function $e(t, n, e, r) {
        this._groups = t,
        this._parents = n,
        this._name = e,
        this._id = r
    }
    function De(t) {
        return wt().transition(t)
    }
    function Ne() {
        return ++ze
    }
    var Ue = wt.prototype;
    $e.prototype = De.prototype = {
        constructor: $e,
        select: function(t) {
            var n = this._name
              , e = this._id;
            "function" != typeof t && (t = g(t));
            for (var r = this._groups, i = r.length, o = new Array(i), a = 0; a < i; ++a)
                for (var u, l, s = r[a], c = s.length, f = o[a] = new Array(c), h = 0; h < c; ++h)
                    (u = s[h]) && (l = t.call(u, u.__data__, h, s)) && ("__data__"in u && (l.__data__ = u.__data__),
                    f[h] = l,
                    en(f[h], n, e, h, f, an(u, e)));
            return new $e(o,this._parents,n,e)
        },
        selectAll: function(t) {
            var n = this._name
              , e = this._id;
            "function" != typeof t && (t = m(t));
            for (var r = this._groups, i = r.length, o = [], a = [], u = 0; u < i; ++u)
                for (var l, s = r[u], c = s.length, f = 0; f < c; ++f)
                    if (l = s[f]) {
                        for (var h, p = t.call(l, l.__data__, f, s), d = an(l, e), y = 0, g = p.length; y < g; ++y)
                            (h = p[y]) && en(h, n, e, y, p, d);
                        o.push(p),
                        a.push(l)
                    }
            return new $e(o,a,n,e)
        },
        selectChild: Ue.selectChild,
        selectChildren: Ue.selectChildren,
        filter: function(t) {
            "function" != typeof t && (t = w(t));
            for (var n = this._groups, e = n.length, r = new Array(e), i = 0; i < e; ++i)
                for (var o, a = n[i], u = a.length, l = r[i] = [], s = 0; s < u; ++s)
                    (o = a[s]) && t.call(o, o.__data__, s, a) && l.push(o);
            return new $e(r,this._parents,this._name,this._id)
        },
        merge: function(t) {
            if (t._id !== this._id)
                throw new Error;
            for (var n = this._groups, e = t._groups, r = n.length, i = e.length, o = Math.min(r, i), a = new Array(r), u = 0; u < o; ++u)
                for (var l, s = n[u], c = e[u], f = s.length, h = a[u] = new Array(f), p = 0; p < f; ++p)
                    (l = s[p] || c[p]) && (h[p] = l);
            for (; u < r; ++u)
                a[u] = n[u];
            return new $e(a,this._parents,this._name,this._id)
        },
        selection: function() {
            return new ke(this._groups,this._parents)
        },
        transition: function() {
            for (var t = this._name, n = this._id, e = Ne(), r = this._groups, i = r.length, o = 0; o < i; ++o)
                for (var a, u = r[o], l = u.length, s = 0; s < l; ++s)
                    if (a = u[s]) {
                        var c = an(a, n);
                        en(a, t, e, s, u, {
                            time: c.time + c.delay + c.duration,
                            delay: 0,
                            duration: c.duration,
                            ease: c.ease
                        })
                    }
            return new $e(r,this._parents,t,e)
        },
        call: Ue.call,
        nodes: Ue.nodes,
        node: Ue.node,
        size: Ue.size,
        empty: Ue.empty,
        each: Ue.each,
        on: function(t, n) {
            var e = this._id;
            return arguments.length < 2 ? an(this.node(), e).on.on(t) : this.each(function(t, n, e) {
                var r, i, o = function(t) {
                    return (t + "").trim().split(/^|\s+/).every((function(t) {
                        var n = t.indexOf(".");
                        return n >= 0 && (t = t.slice(0, n)),
                        !t || "start" === t
                    }
                    ))
                }(n) ? rn : on;
                return function() {
                    var a = o(this, t)
                      , u = a.on;
                    u !== r && (i = (r = u).copy()).on(n, e),
                    a.on = i
                }
            }(e, t, n))
        },
        attr: function(t, n) {
            var e = f(t)
              , r = "transform" === e ? le : ye;
            return this.attrTween(t, "function" == typeof n ? (e.local ? be : we)(e, r, de(this, "attr." + t, n)) : null == n ? (e.local ? ve : ge)(e) : (e.local ? _e : me)(e, r, n))
        },
        attrTween: function(t, n) {
            var e = "attr." + t;
            if (arguments.length < 2)
                return (e = this.tween(e)) && e._value;
            if (null == n)
                return this.tween(e, null);
            if ("function" != typeof n)
                throw new Error;
            var r = f(t);
            return this.tween(e, (r.local ? xe : Me)(r, n))
        },
        style: function(t, n, e) {
            var r = "transform" == (t += "") ? ue : ye;
            return null == n ? this.styleTween(t, function(t, n) {
                var e, r, i;
                return function() {
                    var o = q(this, t)
                      , a = (this.style.removeProperty(t),
                    q(this, t));
                    return o === a ? null : o === e && a === r ? i : i = n(e = o, r = a)
                }
            }(t, r)).on("end.style." + t, Ee(t)) : "function" == typeof n ? this.styleTween(t, function(t, n, e) {
                var r, i, o;
                return function() {
                    var a = q(this, t)
                      , u = e(this)
                      , l = u + "";
                    return null == u && (this.style.removeProperty(t),
                    l = u = q(this, t)),
                    a === l ? null : a === r && l === i ? o : (i = l,
                    o = n(r = a, u))
                }
            }(t, r, de(this, "style." + t, n))).each(function(t, n) {
                var e, r, i, o, a = "style." + n, u = "end." + a;
                return function() {
                    var l = on(this, t)
                      , s = l.on
                      , c = null == l.value[a] ? o || (o = Ee(n)) : void 0;
                    s === e && i === c || (r = (e = s).copy()).on(u, i = c),
                    l.on = r
                }
            }(this._id, t)) : this.styleTween(t, function(t, n, e) {
                var r, i, o = e + "";
                return function() {
                    var a = q(this, t);
                    return a === o ? null : a === r ? i : i = n(r = a, e)
                }
            }(t, r, n), e).on("end.style." + t, null)
        },
        styleTween: function(t, n, e) {
            var r = "style." + (t += "");
            if (arguments.length < 2)
                return (r = this.tween(r)) && r._value;
            if (null == n)
                return this.tween(r, null);
            if ("function" != typeof n)
                throw new Error;
            return this.tween(r, function(t, n, e) {
                var r, i;
                function o() {
                    var o = n.apply(this, arguments);
                    return o !== i && (r = (i = o) && function(t, n, e) {
                        return function(r) {
                            this.style.setProperty(t, n.call(this, r), e)
                        }
                    }(t, o, e)),
                    r
                }
                return o._value = n,
                o
            }(t, n, null == e ? "" : e))
        },
        text: function(t) {
            return this.tween("text", "function" == typeof t ? function(t) {
                return function() {
                    var n = t(this);
                    this.textContent = null == n ? "" : n
                }
            }(de(this, "text", t)) : function(t) {
                return function() {
                    this.textContent = t
                }
            }(null == t ? "" : t + ""))
        },
        textTween: function(t) {
            var n = "text";
            if (arguments.length < 1)
                return (n = this.tween(n)) && n._value;
            if (null == t)
                return this.tween(n, null);
            if ("function" != typeof t)
                throw new Error;
            return this.tween(n, function(t) {
                var n, e;
                function r() {
                    var r = t.apply(this, arguments);
                    return r !== e && (n = (e = r) && function(t) {
                        return function(n) {
                            this.textContent = t.call(this, n)
                        }
                    }(r)),
                    n
                }
                return r._value = t,
                r
            }(t))
        },
        remove: function() {
            return this.on("end.remove", function(t) {
                return function() {
                    var n = this.parentNode;
                    for (var e in this.__transition)
                        if (+e !== t)
                            return;
                    n && n.removeChild(this)
                }
            }(this._id))
        },
        tween: function(t, n) {
            var e = this._id;
            if (t += "",
            arguments.length < 2) {
                for (var r, i = an(this.node(), e).tween, o = 0, a = i.length; o < a; ++o)
                    if ((r = i[o]).name === t)
                        return r.value;
                return null
            }
            return this.each((null == n ? he : pe)(e, t, n))
        },
        delay: function(t) {
            var n = this._id;
            return arguments.length ? this.each(("function" == typeof t ? Se : Ce)(n, t)) : an(this.node(), n).delay
        },
        duration: function(t) {
            var n = this._id;
            return arguments.length ? this.each(("function" == typeof t ? Te : Ae)(n, t)) : an(this.node(), n).duration
        },
        ease: function(t) {
            var n = this._id;
            return arguments.length ? this.each(function(t, n) {
                if ("function" != typeof n)
                    throw new Error;
                return function() {
                    on(this, t).ease = n
                }
            }(n, t)) : an(this.node(), n).ease
        },
        easeVarying: function(t) {
            if ("function" != typeof t)
                throw new Error;
            return this.each(function(t, n) {
                return function() {
                    var e = n.apply(this, arguments);
                    if ("function" != typeof e)
                        throw new Error;
                    on(this, t).ease = e
                }
            }(this._id, t))
        },
        end: function() {
            var t, n, e = this, r = e._id, i = e.size();
            return new Promise((function(o, a) {
                var u = {
                    value: a
                }
                  , l = {
                    value: function() {
                        0 == --i && o()
                    }
                };
                e.each((function() {
                    var e = on(this, r)
                      , i = e.on;
                    i !== t && ((n = (t = i).copy())._.cancel.push(u),
                    n._.interrupt.push(u),
                    n._.end.push(l)),
                    e.on = n
                }
                )),
                0 === i && o()
            }
            ))
        },
        [Symbol.iterator]: Ue[Symbol.iterator]
    };
    var je = {
        time: null,
        delay: 0,
        duration: 250,
        ease: function(t) {
            return ((t *= 2) <= 1 ? t * t * t : (t -= 2) * t * t + 2) / 2
        }
    };
    function Oe(t, n) {
        for (var e; !(e = t.__transition) || !(e = e[n]); )
            if (!(t = t.parentNode))
                throw new Error(`transition ${n} not found`);
        return e
    }
    wt.prototype.interrupt = function(t) {
        return this.each((function() {
            un(this, t)
        }
        ))
    }
    ,
    wt.prototype.transition = function(t) {
        var n, e;
        t instanceof $e ? (n = t._id,
        t = t._name) : (n = Ne(),
        (e = je).time = Ft(),
        t = null == t ? null : t + "");
        for (var r = this._groups, i = r.length, o = 0; o < i; ++o)
            for (var a, u = r[o], l = u.length, s = 0; s < l; ++s)
                (a = u[s]) && en(a, t, n, s, u, e || Oe(a, n));
        return new $e(r,this._parents,t,n)
    }
    ;
    const Pe = {
        capture: !0,
        passive: !1
    };
    function He(t) {
        t.preventDefault(),
        t.stopImmediatePropagation()
    }
    var Fe = t => () => t;
    function Ye(t, {sourceEvent: n, target: e, transform: r, dispatch: i}) {
        Object.defineProperties(this, {
            type: {
                value: t,
                enumerable: !0,
                configurable: !0
            },
            sourceEvent: {
                value: n,
                enumerable: !0,
                configurable: !0
            },
            target: {
                value: e,
                enumerable: !0,
                configurable: !0
            },
            transform: {
                value: r,
                enumerable: !0,
                configurable: !0
            },
            _: {
                value: i
            }
        })
    }
    function Ie(t, n, e) {
        this.k = t,
        this.x = n,
        this.y = e
    }
    Ie.prototype = {
        constructor: Ie,
        scale: function(t) {
            return 1 === t ? this : new Ie(this.k * t,this.x,this.y)
        },
        translate: function(t, n) {
            return 0 === t & 0 === n ? this : new Ie(this.k,this.x + this.k * t,this.y + this.k * n)
        },
        apply: function(t) {
            return [t[0] * this.k + this.x, t[1] * this.k + this.y]
        },
        applyX: function(t) {
            return t * this.k + this.x
        },
        applyY: function(t) {
            return t * this.k + this.y
        },
        invert: function(t) {
            return [(t[0] - this.x) / this.k, (t[1] - this.y) / this.k]
        },
        invertX: function(t) {
            return (t - this.x) / this.k
        },
        invertY: function(t) {
            return (t - this.y) / this.k
        },
        rescaleX: function(t) {
            return t.copy().domain(t.range().map(this.invertX, this).map(t.invert, t))
        },
        rescaleY: function(t) {
            return t.copy().domain(t.range().map(this.invertY, this).map(t.invert, t))
        },
        toString: function() {
            return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")"
        }
    };
    var Le = new Ie(1,0,0);
    function qe(t) {
        for (; !t.__zoom; )
            if (!(t = t.parentNode))
                return Le;
        return t.__zoom
    }
    function Xe(t) {
        t.stopImmediatePropagation()
    }
    function Ve(t) {
        t.preventDefault(),
        t.stopImmediatePropagation()
    }
    function Re(t) {
        return !(t.ctrlKey && "wheel" !== t.type || t.button)
    }
    function Be() {
        var t = this;
        return t instanceof SVGElement ? (t = t.ownerSVGElement || t).hasAttribute("viewBox") ? [[(t = t.viewBox.baseVal).x, t.y], [t.x + t.width, t.y + t.height]] : [[0, 0], [t.width.baseVal.value, t.height.baseVal.value]] : [[0, 0], [t.clientWidth, t.clientHeight]]
    }
    function Ze() {
        return this.__zoom || Le
    }
    function We(t) {
        return -t.deltaY * (1 === t.deltaMode ? .05 : t.deltaMode ? 1 : .002) * (t.ctrlKey ? 10 : 1)
    }
    function Ge() {
        return navigator.maxTouchPoints || "ontouchstart"in this
    }
    function Qe(t, n, e) {
        var r = t.invertX(n[0][0]) - e[0][0]
          , i = t.invertX(n[1][0]) - e[1][0]
          , o = t.invertY(n[0][1]) - e[0][1]
          , a = t.invertY(n[1][1]) - e[1][1];
        return t.translate(i > r ? (r + i) / 2 : Math.min(0, r) || Math.max(0, i), a > o ? (o + a) / 2 : Math.min(0, o) || Math.max(0, a))
    }
    function Je() {
        var t, n, e, r = Re, i = Be, o = Qe, a = We, u = Ge, l = [0, 1 / 0], s = [[-1 / 0, -1 / 0], [1 / 0, 1 / 0]], c = 250, f = fe, h = St("start", "zoom", "end"), p = 500, d = 150, y = 0, g = 10;
        function v(t) {
            t.property("__zoom", Ze).on("wheel.zoom", S, {
                passive: !1
            }).on("mousedown.zoom", C).on("dblclick.zoom", T).filter(u).on("touchstart.zoom", A).on("touchmove.zoom", k).on("touchend.zoom touchcancel.zoom", E).style("-webkit-tap-highlight-color", "rgba(0,0,0,0)")
        }
        function m(t, n) {
            return (n = Math.max(l[0], Math.min(l[1], n))) === t.k ? t : new Ie(n,t.x,t.y)
        }
        function _(t, n, e) {
            var r = n[0] - e[0] * t.k
              , i = n[1] - e[1] * t.k;
            return r === t.x && i === t.y ? t : new Ie(t.k,r,i)
        }
        function w(t) {
            return [(+t[0][0] + +t[1][0]) / 2, (+t[0][1] + +t[1][1]) / 2]
        }
        function b(t, n, e, r) {
            t.on("start.zoom", (function() {
                x(this, arguments).event(r).start()
            }
            )).on("interrupt.zoom end.zoom", (function() {
                x(this, arguments).event(r).end()
            }
            )).tween("zoom", (function() {
                var t = this
                  , o = arguments
                  , a = x(t, o).event(r)
                  , u = i.apply(t, o)
                  , l = null == e ? w(u) : "function" == typeof e ? e.apply(t, o) : e
                  , s = Math.max(u[1][0] - u[0][0], u[1][1] - u[0][1])
                  , c = t.__zoom
                  , h = "function" == typeof n ? n.apply(t, o) : n
                  , p = f(c.invert(l).concat(s / c.k), h.invert(l).concat(s / h.k));
                return function(t) {
                    if (1 === t)
                        t = h;
                    else {
                        var n = p(t)
                          , e = s / n[2];
                        t = new Ie(e,l[0] - n[0] * e,l[1] - n[1] * e)
                    }
                    a.zoom(null, t)
                }
            }
            ))
        }
        function x(t, n, e) {
            return !e && t.__zooming || new M(t,n)
        }
        function M(t, n) {
            this.that = t,
            this.args = n,
            this.active = 0,
            this.sourceEvent = null,
            this.extent = i.apply(t, n),
            this.taps = 0
        }
        function S(t, ...n) {
            if (r.apply(this, arguments)) {
                var e = x(this, n).event(t)
                  , i = this.__zoom
                  , u = Math.max(l[0], Math.min(l[1], i.k * Math.pow(2, a.apply(this, arguments))))
                  , c = xt(t);
                if (e.wheel)
                    e.mouse[0][0] === c[0] && e.mouse[0][1] === c[1] || (e.mouse[1] = i.invert(e.mouse[0] = c)),
                    clearTimeout(e.wheel);
                else {
                    if (i.k === u)
                        return;
                    e.mouse = [c, i.invert(c)],
                    un(this),
                    e.start()
                }
                Ve(t),
                e.wheel = setTimeout((function() {
                    e.wheel = null,
                    e.end()
                }
                ), d),
                e.zoom("mouse", o(_(m(i, u), e.mouse[0], e.mouse[1]), e.extent, s))
            }
        }
        function C(t, ...n) {
            if (!e && r.apply(this, arguments)) {
                var i = t.currentTarget
                  , a = x(this, n, !0).event(t)
                  , u = bt(t.view).on("mousemove.zoom", (function(t) {
                    if (Ve(t),
                    !a.moved) {
                        var n = t.clientX - c
                          , e = t.clientY - f;
                        a.moved = n * n + e * e > y
                    }
                    a.event(t).zoom("mouse", o(_(a.that.__zoom, a.mouse[0] = xt(t, i), a.mouse[1]), a.extent, s))
                }
                ), !0).on("mouseup.zoom", (function(t) {
                    u.on("mousemove.zoom mouseup.zoom", null),
                    function(t, n) {
                        var e = t.document.documentElement
                          , r = bt(t).on("dragstart.drag", null);
                        n && (r.on("click.drag", He, Pe),
                        setTimeout((function() {
                            r.on("click.drag", null)
                        }
                        ), 0)),
                        "onselectstart"in e ? r.on("selectstart.drag", null) : (e.style.MozUserSelect = e.__noselect,
                        delete e.__noselect)
                    }(t.view, a.moved),
                    Ve(t),
                    a.event(t).end()
                }
                ), !0)
                  , l = xt(t, i)
                  , c = t.clientX
                  , f = t.clientY;
                !function(t) {
                    var n = t.document.documentElement
                      , e = bt(t).on("dragstart.drag", He, Pe);
                    "onselectstart"in n ? e.on("selectstart.drag", He, Pe) : (n.__noselect = n.style.MozUserSelect,
                    n.style.MozUserSelect = "none")
                }(t.view),
                Xe(t),
                a.mouse = [l, this.__zoom.invert(l)],
                un(this),
                a.start()
            }
        }
        function T(t, ...n) {
            if (r.apply(this, arguments)) {
                var e = this.__zoom
                  , a = xt(t.changedTouches ? t.changedTouches[0] : t, this)
                  , u = e.invert(a)
                  , l = e.k * (t.shiftKey ? .5 : 2)
                  , f = o(_(m(e, l), a, u), i.apply(this, n), s);
                Ve(t),
                c > 0 ? bt(this).transition().duration(c).call(b, f, a, t) : bt(this).call(v.transform, f, a, t)
            }
        }
        function A(e, ...i) {
            if (r.apply(this, arguments)) {
                var o, a, u, l, s = e.touches, c = s.length, f = x(this, i, e.changedTouches.length === c).event(e);
                for (Xe(e),
                a = 0; a < c; ++a)
                    l = [l = xt(u = s[a], this), this.__zoom.invert(l), u.identifier],
                    f.touch0 ? f.touch1 || f.touch0[2] === l[2] || (f.touch1 = l,
                    f.taps = 0) : (f.touch0 = l,
                    o = !0,
                    f.taps = 1 + !!t);
                t && (t = clearTimeout(t)),
                o && (f.taps < 2 && (n = l[0],
                t = setTimeout((function() {
                    t = null
                }
                ), p)),
                un(this),
                f.start())
            }
        }
        function k(t, ...n) {
            if (this.__zooming) {
                var e, r, i, a, u = x(this, n).event(t), l = t.changedTouches, c = l.length;
                for (Ve(t),
                e = 0; e < c; ++e)
                    i = xt(r = l[e], this),
                    u.touch0 && u.touch0[2] === r.identifier ? u.touch0[0] = i : u.touch1 && u.touch1[2] === r.identifier && (u.touch1[0] = i);
                if (r = u.that.__zoom,
                u.touch1) {
                    var f = u.touch0[0]
                      , h = u.touch0[1]
                      , p = u.touch1[0]
                      , d = u.touch1[1]
                      , y = (y = p[0] - f[0]) * y + (y = p[1] - f[1]) * y
                      , g = (g = d[0] - h[0]) * g + (g = d[1] - h[1]) * g;
                    r = m(r, Math.sqrt(y / g)),
                    i = [(f[0] + p[0]) / 2, (f[1] + p[1]) / 2],
                    a = [(h[0] + d[0]) / 2, (h[1] + d[1]) / 2]
                } else {
                    if (!u.touch0)
                        return;
                    i = u.touch0[0],
                    a = u.touch0[1]
                }
                u.zoom("touch", o(_(r, i, a), u.extent, s))
            }
        }
        function E(t, ...r) {
            if (this.__zooming) {
                var i, o, a = x(this, r).event(t), u = t.changedTouches, l = u.length;
                for (Xe(t),
                e && clearTimeout(e),
                e = setTimeout((function() {
                    e = null
                }
                ), p),
                i = 0; i < l; ++i)
                    o = u[i],
                    a.touch0 && a.touch0[2] === o.identifier ? delete a.touch0 : a.touch1 && a.touch1[2] === o.identifier && delete a.touch1;
                if (a.touch1 && !a.touch0 && (a.touch0 = a.touch1,
                delete a.touch1),
                a.touch0)
                    a.touch0[1] = this.__zoom.invert(a.touch0[0]);
                else if (a.end(),
                2 === a.taps && (o = xt(o, this),
                Math.hypot(n[0] - o[0], n[1] - o[1]) < g)) {
                    var s = bt(this).on("dblclick.zoom");
                    s && s.apply(this, arguments)
                }
            }
        }
        return v.transform = function(t, n, e, r) {
            var i = t.selection ? t.selection() : t;
            i.property("__zoom", Ze),
            t !== i ? b(t, n, e, r) : i.interrupt().each((function() {
                x(this, arguments).event(r).start().zoom(null, "function" == typeof n ? n.apply(this, arguments) : n).end()
            }
            ))
        }
        ,
        v.scaleBy = function(t, n, e, r) {
            v.scaleTo(t, (function() {
                return this.__zoom.k * ("function" == typeof n ? n.apply(this, arguments) : n)
            }
            ), e, r)
        }
        ,
        v.scaleTo = function(t, n, e, r) {
            v.transform(t, (function() {
                var t = i.apply(this, arguments)
                  , r = this.__zoom
                  , a = null == e ? w(t) : "function" == typeof e ? e.apply(this, arguments) : e
                  , u = r.invert(a)
                  , l = "function" == typeof n ? n.apply(this, arguments) : n;
                return o(_(m(r, l), a, u), t, s)
            }
            ), e, r)
        }
        ,
        v.translateBy = function(t, n, e, r) {
            v.transform(t, (function() {
                return o(this.__zoom.translate("function" == typeof n ? n.apply(this, arguments) : n, "function" == typeof e ? e.apply(this, arguments) : e), i.apply(this, arguments), s)
            }
            ), null, r)
        }
        ,
        v.translateTo = function(t, n, e, r, a) {
            v.transform(t, (function() {
                var t = i.apply(this, arguments)
                  , a = this.__zoom
                  , u = null == r ? w(t) : "function" == typeof r ? r.apply(this, arguments) : r;
                return o(Le.translate(u[0], u[1]).scale(a.k).translate("function" == typeof n ? -n.apply(this, arguments) : -n, "function" == typeof e ? -e.apply(this, arguments) : -e), t, s)
            }
            ), r, a)
        }
        ,
        M.prototype = {
            event: function(t) {
                return t && (this.sourceEvent = t),
                this
            },
            start: function() {
                return 1 == ++this.active && (this.that.__zooming = this,
                this.emit("start")),
                this
            },
            zoom: function(t, n) {
                return this.mouse && "mouse" !== t && (this.mouse[1] = n.invert(this.mouse[0])),
                this.touch0 && "touch" !== t && (this.touch0[1] = n.invert(this.touch0[0])),
                this.touch1 && "touch" !== t && (this.touch1[1] = n.invert(this.touch1[0])),
                this.that.__zoom = n,
                this.emit("zoom"),
                this
            },
            end: function() {
                return 0 == --this.active && (delete this.that.__zooming,
                this.emit("end")),
                this
            },
            emit: function(t) {
                var n = bt(this.that).datum();
                h.call(t, this.that, new Ye(t,{
                    sourceEvent: this.sourceEvent,
                    target: v,
                    type: t,
                    transform: this.that.__zoom,
                    dispatch: h
                }), n)
            }
        },
        v.wheelDelta = function(t) {
            return arguments.length ? (a = "function" == typeof t ? t : Fe(+t),
            v) : a
        }
        ,
        v.filter = function(t) {
            return arguments.length ? (r = "function" == typeof t ? t : Fe(!!t),
            v) : r
        }
        ,
        v.touchable = function(t) {
            return arguments.length ? (u = "function" == typeof t ? t : Fe(!!t),
            v) : u
        }
        ,
        v.extent = function(t) {
            return arguments.length ? (i = "function" == typeof t ? t : Fe([[+t[0][0], +t[0][1]], [+t[1][0], +t[1][1]]]),
            v) : i
        }
        ,
        v.scaleExtent = function(t) {
            return arguments.length ? (l[0] = +t[0],
            l[1] = +t[1],
            v) : [l[0], l[1]]
        }
        ,
        v.translateExtent = function(t) {
            return arguments.length ? (s[0][0] = +t[0][0],
            s[1][0] = +t[1][0],
            s[0][1] = +t[0][1],
            s[1][1] = +t[1][1],
            v) : [[s[0][0], s[0][1]], [s[1][0], s[1][1]]]
        }
        ,
        v.constrain = function(t) {
            return arguments.length ? (o = t,
            v) : o
        }
        ,
        v.duration = function(t) {
            return arguments.length ? (c = +t,
            v) : c
        }
        ,
        v.interpolate = function(t) {
            return arguments.length ? (f = t,
            v) : f
        }
        ,
        v.on = function() {
            var t = h.on.apply(h, arguments);
            return t === h ? v : t
        }
        ,
        v.clickDistance = function(t) {
            return arguments.length ? (y = (t = +t) * t,
            v) : Math.sqrt(y)
        }
        ,
        v.tapDistance = function(t) {
            return arguments.length ? (g = +t,
            v) : g
        }
        ,
        v
    }
    function Ke(t) {
        return t
    }
    qe.prototype = Ie.prototype;
    var tr = 1
      , nr = 2
      , er = 3
      , rr = 4
      , ir = 1e-6;
    function or(t) {
        return "translate(" + t + ",0)"
    }
    function ar(t) {
        return "translate(0," + t + ")"
    }
    function ur(t) {
        return n => +t(n)
    }
    function lr(t, n) {
        return n = Math.max(0, t.bandwidth() - 2 * n) / 2,
        t.round() && (n = Math.round(n)),
        e => +t(e) + n
    }
    function sr() {
        return !this.__axis
    }
    function cr(t, n) {
        var e = []
          , r = null
          , i = null
          , o = 6
          , a = 6
          , u = 3
          , l = "undefined" != typeof window && window.devicePixelRatio > 1 ? 0 : .5
          , s = t === tr || t === rr ? -1 : 1
          , c = t === rr || t === nr ? "x" : "y"
          , f = t === tr || t === er ? or : ar;
        function h(h) {
            var p = null == r ? n.ticks ? n.ticks.apply(n, e) : n.domain() : r
              , d = null == i ? n.tickFormat ? n.tickFormat.apply(n, e) : Ke : i
              , y = Math.max(o, 0) + u
              , g = n.range()
              , v = +g[0] + l
              , m = +g[g.length - 1] + l
              , _ = (n.bandwidth ? lr : ur)(n.copy(), l)
              , w = h.selection ? h.selection() : h
              , b = w.selectAll(".domain").data([null])
              , x = w.selectAll(".tick").data(p, n).order()
              , M = x.exit()
              , S = x.enter().append("g").attr("class", "tick")
              , C = x.select("line")
              , T = x.select("text");
            b = b.merge(b.enter().insert("path", ".tick").attr("class", "domain").attr("stroke", "currentColor")),
            x = x.merge(S),
            C = C.merge(S.append("line").attr("stroke", "currentColor").attr(c + "2", s * o)),
            T = T.merge(S.append("text").attr("fill", "currentColor").attr(c, s * y).attr("dy", t === tr ? "0em" : t === er ? "0.71em" : "0.32em")),
            h !== w && (b = b.transition(h),
            x = x.transition(h),
            C = C.transition(h),
            T = T.transition(h),
            M = M.transition(h).attr("opacity", ir).attr("transform", (function(t) {
                return isFinite(t = _(t)) ? f(t + l) : this.getAttribute("transform")
            }
            )),
            S.attr("opacity", ir).attr("transform", (function(t) {
                var n = this.parentNode.__axis;
                return f((n && isFinite(n = n(t)) ? n : _(t)) + l)
            }
            ))),
            M.remove(),
            b.attr("d", t === rr || t === nr ? a ? "M" + s * a + "," + v + "H" + l + "V" + m + "H" + s * a : "M" + l + "," + v + "V" + m : a ? "M" + v + "," + s * a + "V" + l + "H" + m + "V" + s * a : "M" + v + "," + l + "H" + m),
            x.attr("opacity", 1).attr("transform", (function(t) {
                return f(_(t) + l)
            }
            )),
            C.attr(c + "2", s * o),
            T.attr(c, s * y).text(d),
            w.filter(sr).attr("fill", "none").attr("font-size", 10).attr("font-family", "sans-serif").attr("text-anchor", t === nr ? "start" : t === rr ? "end" : "middle"),
            w.each((function() {
                this.__axis = _
            }
            ))
        }
        return h.scale = function(t) {
            return arguments.length ? (n = t,
            h) : n
        }
        ,
        h.ticks = function() {
            return e = Array.from(arguments),
            h
        }
        ,
        h.tickArguments = function(t) {
            return arguments.length ? (e = null == t ? [] : Array.from(t),
            h) : e.slice()
        }
        ,
        h.tickValues = function(t) {
            return arguments.length ? (r = null == t ? null : Array.from(t),
            h) : r && r.slice()
        }
        ,
        h.tickFormat = function(t) {
            return arguments.length ? (i = t,
            h) : i
        }
        ,
        h.tickSize = function(t) {
            return arguments.length ? (o = a = +t,
            h) : o
        }
        ,
        h.tickSizeInner = function(t) {
            return arguments.length ? (o = +t,
            h) : o
        }
        ,
        h.tickSizeOuter = function(t) {
            return arguments.length ? (a = +t,
            h) : a
        }
        ,
        h.tickPadding = function(t) {
            return arguments.length ? (u = +t,
            h) : u
        }
        ,
        h.offset = function(t) {
            return arguments.length ? (l = +t,
            h) : l
        }
        ,
        h
    }
    function fr(t, n) {
        return null == t || null == n ? NaN : t < n ? -1 : t > n ? 1 : t >= n ? 0 : NaN
    }
    function hr(t, n) {
        return null == t || null == n ? NaN : n < t ? -1 : n > t ? 1 : n >= t ? 0 : NaN
    }
    function pr(t) {
        let n, e, r;
        function i(t, r, i=0, o=t.length) {
            if (i < o) {
                if (0 !== n(r, r))
                    return o;
                do {
                    const n = i + o >>> 1;
                    e(t[n], r) < 0 ? i = n + 1 : o = n
                } while (i < o)
            }
            return i
        }
        return 2 !== t.length ? (n = fr,
        e = (n, e) => fr(t(n), e),
        r = (n, e) => t(n) - e) : (n = t === fr || t === hr ? t : dr,
        e = t,
        r = t),
        {
            left: i,
            center: function(t, n, e=0, o=t.length) {
                const a = i(t, n, e, o - 1);
                return a > e && r(t[a - 1], n) > -r(t[a], n) ? a - 1 : a
            },
            right: function(t, r, i=0, o=t.length) {
                if (i < o) {
                    if (0 !== n(r, r))
                        return o;
                    do {
                        const n = i + o >>> 1;
                        e(t[n], r) <= 0 ? i = n + 1 : o = n
                    } while (i < o)
                }
                return i
            }
        }
    }
    function dr() {
        return 0
    }
    const yr = pr(fr).right;
    pr((function(t) {
        return null === t ? NaN : +t
    }
    )).center;
    var gr = yr;
    const vr = Math.sqrt(50)
      , mr = Math.sqrt(10)
      , _r = Math.sqrt(2);
    function wr(t, n, e) {
        const r = (n - t) / Math.max(0, e)
          , i = Math.floor(Math.log10(r))
          , o = r / Math.pow(10, i)
          , a = o >= vr ? 10 : o >= mr ? 5 : o >= _r ? 2 : 1;
        let u, l, s;
        return i < 0 ? (s = Math.pow(10, -i) / a,
        u = Math.round(t * s),
        l = Math.round(n * s),
        u / s < t && ++u,
        l / s > n && --l,
        s = -s) : (s = Math.pow(10, i) * a,
        u = Math.round(t / s),
        l = Math.round(n / s),
        u * s < t && ++u,
        l * s > n && --l),
        l < u && .5 <= e && e < 2 ? wr(t, n, 2 * e) : [u, l, s]
    }
    function br(t, n, e) {
        return wr(t = +t, n = +n, e = +e)[2]
    }
    function xr(t, n, e) {
        e = +e;
        const r = (n = +n) < (t = +t)
          , i = r ? br(n, t, e) : br(t, n, e);
        return (r ? -1 : 1) * (i < 0 ? 1 / -i : i)
    }
    function Mr(t, n, e) {
        t = +t,
        n = +n,
        e = (i = arguments.length) < 2 ? (n = t,
        t = 0,
        1) : i < 3 ? 1 : +e;
        for (var r = -1, i = 0 | Math.max(0, Math.ceil((n - t) / e)), o = new Array(i); ++r < i; )
            o[r] = t + r * e;
        return o
    }
    function Sr(t, n) {
        switch (arguments.length) {
        case 0:
            break;
        case 1:
            this.range(t);
            break;
        default:
            this.range(n).domain(t)
        }
        return this
    }
    function Cr(t) {
        return +t
    }
    var Tr = [0, 1];
    function Ar(t) {
        return t
    }
    function kr(t, n) {
        return (n -= t = +t) ? function(e) {
            return (e - t) / n
        }
        : function(t) {
            return function() {
                return t
            }
        }(isNaN(n) ? NaN : .5)
    }
    function Er(t, n, e) {
        var r = t[0]
          , i = t[1]
          , o = n[0]
          , a = n[1];
        return i < r ? (r = kr(i, r),
        o = e(a, o)) : (r = kr(r, i),
        o = e(o, a)),
        function(t) {
            return o(r(t))
        }
    }
    function zr(t, n, e) {
        var r = Math.min(t.length, n.length) - 1
          , i = new Array(r)
          , o = new Array(r)
          , a = -1;
        for (t[r] < t[0] && (t = t.slice().reverse(),
        n = n.slice().reverse()); ++a < r; )
            i[a] = kr(t[a], t[a + 1]),
            o[a] = e(n[a], n[a + 1]);
        return function(n) {
            var e = gr(t, n, 1, r) - 1;
            return o[e](i[e](n))
        }
    }
    function $r(t, n) {
        return n.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp()).unknown(t.unknown())
    }
    function Dr() {
        var t, n, e, r, i, o, a = Tr, u = Tr, l = te, s = Ar;
        function c() {
            var t, n, e, l = Math.min(a.length, u.length);
            return s !== Ar && (t = a[0],
            n = a[l - 1],
            t > n && (e = t,
            t = n,
            n = e),
            s = function(e) {
                return Math.max(t, Math.min(n, e))
            }
            ),
            r = l > 2 ? zr : Er,
            i = o = null,
            f
        }
        function f(n) {
            return null == n || isNaN(n = +n) ? e : (i || (i = r(a.map(t), u, l)))(t(s(n)))
        }
        return f.invert = function(e) {
            return s(n((o || (o = r(u, a.map(t), Wn)))(e)))
        }
        ,
        f.domain = function(t) {
            return arguments.length ? (a = Array.from(t, Cr),
            c()) : a.slice()
        }
        ,
        f.range = function(t) {
            return arguments.length ? (u = Array.from(t),
            c()) : u.slice()
        }
        ,
        f.rangeRound = function(t) {
            return u = Array.from(t),
            l = ne,
            c()
        }
        ,
        f.clamp = function(t) {
            return arguments.length ? (s = !!t || Ar,
            c()) : s !== Ar
        }
        ,
        f.interpolate = function(t) {
            return arguments.length ? (l = t,
            c()) : l
        }
        ,
        f.unknown = function(t) {
            return arguments.length ? (e = t,
            f) : e
        }
        ,
        function(e, r) {
            return t = e,
            n = r,
            c()
        }
    }
    function Nr() {
        return Dr()(Ar, Ar)
    }
    function Ur(t, n) {
        if ((e = (t = n ? t.toExponential(n - 1) : t.toExponential()).indexOf("e")) < 0)
            return null;
        var e, r = t.slice(0, e);
        return [r.length > 1 ? r[0] + r.slice(2) : r, +t.slice(e + 1)]
    }
    function jr(t) {
        return (t = Ur(Math.abs(t))) ? t[1] : NaN
    }
    var Or, Pr = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;
    function Hr(t) {
        if (!(n = Pr.exec(t)))
            throw new Error("invalid format: " + t);
        var n;
        return new Fr({
            fill: n[1],
            align: n[2],
            sign: n[3],
            symbol: n[4],
            zero: n[5],
            width: n[6],
            comma: n[7],
            precision: n[8] && n[8].slice(1),
            trim: n[9],
            type: n[10]
        })
    }
    function Fr(t) {
        this.fill = void 0 === t.fill ? " " : t.fill + "",
        this.align = void 0 === t.align ? ">" : t.align + "",
        this.sign = void 0 === t.sign ? "-" : t.sign + "",
        this.symbol = void 0 === t.symbol ? "" : t.symbol + "",
        this.zero = !!t.zero,
        this.width = void 0 === t.width ? void 0 : +t.width,
        this.comma = !!t.comma,
        this.precision = void 0 === t.precision ? void 0 : +t.precision,
        this.trim = !!t.trim,
        this.type = void 0 === t.type ? "" : t.type + ""
    }
    function Yr(t, n) {
        var e = Ur(t, n);
        if (!e)
            return t + "";
        var r = e[0]
          , i = e[1];
        return i < 0 ? "0." + new Array(-i).join("0") + r : r.length > i + 1 ? r.slice(0, i + 1) + "." + r.slice(i + 1) : r + new Array(i - r.length + 2).join("0")
    }
    Hr.prototype = Fr.prototype,
    Fr.prototype.toString = function() {
        return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (void 0 === this.width ? "" : Math.max(1, 0 | this.width)) + (this.comma ? "," : "") + (void 0 === this.precision ? "" : "." + Math.max(0, 0 | this.precision)) + (this.trim ? "~" : "") + this.type
    }
    ;
    var Ir = {
        "%": (t, n) => (100 * t).toFixed(n),
        b: t => Math.round(t).toString(2),
        c: t => t + "",
        d: function(t) {
            return Math.abs(t = Math.round(t)) >= 1e21 ? t.toLocaleString("en").replace(/,/g, "") : t.toString(10)
        },
        e: (t, n) => t.toExponential(n),
        f: (t, n) => t.toFixed(n),
        g: (t, n) => t.toPrecision(n),
        o: t => Math.round(t).toString(8),
        p: (t, n) => Yr(100 * t, n),
        r: Yr,
        s: function(t, n) {
            var e = Ur(t, n);
            if (!e)
                return t + "";
            var r = e[0]
              , i = e[1]
              , o = i - (Or = 3 * Math.max(-8, Math.min(8, Math.floor(i / 3)))) + 1
              , a = r.length;
            return o === a ? r : o > a ? r + new Array(o - a + 1).join("0") : o > 0 ? r.slice(0, o) + "." + r.slice(o) : "0." + new Array(1 - o).join("0") + Ur(t, Math.max(0, n + o - 1))[0]
        },
        X: t => Math.round(t).toString(16).toUpperCase(),
        x: t => Math.round(t).toString(16)
    };
    function Lr(t) {
        return t
    }
    var qr, Xr, Vr, Rr = Array.prototype.map, Br = ["y", "z", "a", "f", "p", "n", "µ", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];
    function Zr(t) {
        var n, e, r = void 0 === t.grouping || void 0 === t.thousands ? Lr : (n = Rr.call(t.grouping, Number),
        e = t.thousands + "",
        function(t, r) {
            for (var i = t.length, o = [], a = 0, u = n[0], l = 0; i > 0 && u > 0 && (l + u + 1 > r && (u = Math.max(1, r - l)),
            o.push(t.substring(i -= u, i + u)),
            !((l += u + 1) > r)); )
                u = n[a = (a + 1) % n.length];
            return o.reverse().join(e)
        }
        ), i = void 0 === t.currency ? "" : t.currency[0] + "", o = void 0 === t.currency ? "" : t.currency[1] + "", a = void 0 === t.decimal ? "." : t.decimal + "", u = void 0 === t.numerals ? Lr : function(t) {
            return function(n) {
                return n.replace(/[0-9]/g, (function(n) {
                    return t[+n]
                }
                ))
            }
        }(Rr.call(t.numerals, String)), l = void 0 === t.percent ? "%" : t.percent + "", s = void 0 === t.minus ? "−" : t.minus + "", c = void 0 === t.nan ? "NaN" : t.nan + "";
        function f(t) {
            var n = (t = Hr(t)).fill
              , e = t.align
              , f = t.sign
              , h = t.symbol
              , p = t.zero
              , d = t.width
              , y = t.comma
              , g = t.precision
              , v = t.trim
              , m = t.type;
            "n" === m ? (y = !0,
            m = "g") : Ir[m] || (void 0 === g && (g = 12),
            v = !0,
            m = "g"),
            (p || "0" === n && "=" === e) && (p = !0,
            n = "0",
            e = "=");
            var _ = "$" === h ? i : "#" === h && /[boxX]/.test(m) ? "0" + m.toLowerCase() : ""
              , w = "$" === h ? o : /[%p]/.test(m) ? l : ""
              , b = Ir[m]
              , x = /[defgprs%]/.test(m);
            function M(t) {
                var i, o, l, h = _, M = w;
                if ("c" === m)
                    M = b(t) + M,
                    t = "";
                else {
                    var S = (t = +t) < 0 || 1 / t < 0;
                    if (t = isNaN(t) ? c : b(Math.abs(t), g),
                    v && (t = function(t) {
                        t: for (var n, e = t.length, r = 1, i = -1; r < e; ++r)
                            switch (t[r]) {
                            case ".":
                                i = n = r;
                                break;
                            case "0":
                                0 === i && (i = r),
                                n = r;
                                break;
                            default:
                                if (!+t[r])
                                    break t;
                                i > 0 && (i = 0)
                            }
                        return i > 0 ? t.slice(0, i) + t.slice(n + 1) : t
                    }(t)),
                    S && 0 == +t && "+" !== f && (S = !1),
                    h = (S ? "(" === f ? f : s : "-" === f || "(" === f ? "" : f) + h,
                    M = ("s" === m ? Br[8 + Or / 3] : "") + M + (S && "(" === f ? ")" : ""),
                    x)
                        for (i = -1,
                        o = t.length; ++i < o; )
                            if (48 > (l = t.charCodeAt(i)) || l > 57) {
                                M = (46 === l ? a + t.slice(i + 1) : t.slice(i)) + M,
                                t = t.slice(0, i);
                                break
                            }
                }
                y && !p && (t = r(t, 1 / 0));
                var C = h.length + t.length + M.length
                  , T = C < d ? new Array(d - C + 1).join(n) : "";
                switch (y && p && (t = r(T + t, T.length ? d - M.length : 1 / 0),
                T = ""),
                e) {
                case "<":
                    t = h + t + M + T;
                    break;
                case "=":
                    t = h + T + t + M;
                    break;
                case "^":
                    t = T.slice(0, C = T.length >> 1) + h + t + M + T.slice(C);
                    break;
                default:
                    t = T + h + t + M
                }
                return u(t)
            }
            return g = void 0 === g ? 6 : /[gprs]/.test(m) ? Math.max(1, Math.min(21, g)) : Math.max(0, Math.min(20, g)),
            M.toString = function() {
                return t + ""
            }
            ,
            M
        }
        return {
            format: f,
            formatPrefix: function(t, n) {
                var e = f(((t = Hr(t)).type = "f",
                t))
                  , r = 3 * Math.max(-8, Math.min(8, Math.floor(jr(n) / 3)))
                  , i = Math.pow(10, -r)
                  , o = Br[8 + r / 3];
                return function(t) {
                    return e(i * t) + o
                }
            }
        }
    }
    function Wr(t, n, e, r) {
        var i, o = xr(t, n, e);
        switch ((r = Hr(null == r ? ",f" : r)).type) {
        case "s":
            var a = Math.max(Math.abs(t), Math.abs(n));
            return null != r.precision || isNaN(i = function(t, n) {
                return Math.max(0, 3 * Math.max(-8, Math.min(8, Math.floor(jr(n) / 3))) - jr(Math.abs(t)))
            }(o, a)) || (r.precision = i),
            Vr(r, a);
        case "":
        case "e":
        case "g":
        case "p":
        case "r":
            null != r.precision || isNaN(i = function(t, n) {
                return t = Math.abs(t),
                n = Math.abs(n) - t,
                Math.max(0, jr(n) - jr(t)) + 1
            }(o, Math.max(Math.abs(t), Math.abs(n)))) || (r.precision = i - ("e" === r.type));
            break;
        case "f":
        case "%":
            null != r.precision || isNaN(i = function(t) {
                return Math.max(0, -jr(Math.abs(t)))
            }(o)) || (r.precision = i - 2 * ("%" === r.type))
        }
        return Xr(r)
    }
    function Gr(t) {
        var n = t.domain;
        return t.ticks = function(t) {
            var e = n();
            return function(t, n, e) {
                if (!((e = +e) > 0))
                    return [];
                if ((t = +t) == (n = +n))
                    return [t];
                const r = n < t
                  , [i,o,a] = r ? wr(n, t, e) : wr(t, n, e);
                if (!(o >= i))
                    return [];
                const u = o - i + 1
                  , l = new Array(u);
                if (r)
                    if (a < 0)
                        for (let t = 0; t < u; ++t)
                            l[t] = (o - t) / -a;
                    else
                        for (let t = 0; t < u; ++t)
                            l[t] = (o - t) * a;
                else if (a < 0)
                    for (let t = 0; t < u; ++t)
                        l[t] = (i + t) / -a;
                else
                    for (let t = 0; t < u; ++t)
                        l[t] = (i + t) * a;
                return l
            }(e[0], e[e.length - 1], null == t ? 10 : t)
        }
        ,
        t.tickFormat = function(t, e) {
            var r = n();
            return Wr(r[0], r[r.length - 1], null == t ? 10 : t, e)
        }
        ,
        t.nice = function(e) {
            null == e && (e = 10);
            var r, i, o = n(), a = 0, u = o.length - 1, l = o[a], s = o[u], c = 10;
            for (s < l && (i = l,
            l = s,
            s = i,
            i = a,
            a = u,
            u = i); c-- > 0; ) {
                if ((i = br(l, s, e)) === r)
                    return o[a] = l,
                    o[u] = s,
                    n(o);
                if (i > 0)
                    l = Math.floor(l / i) * i,
                    s = Math.ceil(s / i) * i;
                else {
                    if (!(i < 0))
                        break;
                    l = Math.ceil(l * i) / i,
                    s = Math.floor(s * i) / i
                }
                r = i
            }
            return t
        }
        ,
        t
    }
    function Qr() {
        var t = Nr();
        return t.copy = function() {
            return $r(t, Qr())
        }
        ,
        Sr.apply(t, arguments),
        Gr(t)
    }
    function Jr(t) {
        return function(n) {
            return n < 0 ? -Math.pow(-n, t) : Math.pow(n, t)
        }
    }
    function Kr(t) {
        return t < 0 ? -Math.sqrt(-t) : Math.sqrt(t)
    }
    function ti(t) {
        return t < 0 ? -t * t : t * t
    }
    function ni(t) {
        var n = t(Ar, Ar)
          , e = 1;
        return n.exponent = function(n) {
            return arguments.length ? 1 === (e = +n) ? t(Ar, Ar) : .5 === e ? t(Kr, ti) : t(Jr(e), Jr(1 / e)) : e
        }
        ,
        Gr(n)
    }
    function ei() {
        var t = ni(Dr());
        return t.copy = function() {
            return $r(t, ei()).exponent(t.exponent())
        }
        ,
        Sr.apply(t, arguments),
        t
    }
    qr = Zr({
        thousands: ",",
        grouping: [3],
        currency: ["$", ""]
    }),
    Xr = qr.format,
    Vr = qr.formatPrefix;
    const ri = new Date
      , ii = new Date;
    function oi(t, n, e, r) {
        function i(n) {
            return t(n = 0 === arguments.length ? new Date : new Date(+n)),
            n
        }
        return i.floor = n => (t(n = new Date(+n)),
        n),
        i.ceil = e => (t(e = new Date(e - 1)),
        n(e, 1),
        t(e),
        e),
        i.round = t => {
            const n = i(t)
              , e = i.ceil(t);
            return t - n < e - t ? n : e
        }
        ,
        i.offset = (t, e) => (n(t = new Date(+t), null == e ? 1 : Math.floor(e)),
        t),
        i.range = (e, r, o) => {
            const a = [];
            if (e = i.ceil(e),
            o = null == o ? 1 : Math.floor(o),
            !(e < r && o > 0))
                return a;
            let u;
            do {
                a.push(u = new Date(+e)),
                n(e, o),
                t(e)
            } while (u < e && e < r);
            return a
        }
        ,
        i.filter = e => oi((n => {
            if (n >= n)
                for (; t(n),
                !e(n); )
                    n.setTime(n - 1)
        }
        ), ( (t, r) => {
            if (t >= t)
                if (r < 0)
                    for (; ++r <= 0; )
                        for (; n(t, -1),
                        !e(t); )
                            ;
                else
                    for (; --r >= 0; )
                        for (; n(t, 1),
                        !e(t); )
                            ;
        }
        )),
        e && (i.count = (n, r) => (ri.setTime(+n),
        ii.setTime(+r),
        t(ri),
        t(ii),
        Math.floor(e(ri, ii))),
        i.every = t => (t = Math.floor(t),
        isFinite(t) && t > 0 ? t > 1 ? i.filter(r ? n => r(n) % t == 0 : n => i.count(0, n) % t == 0) : i : null)),
        i
    }
    const ai = oi(( () => {}
    ), ( (t, n) => {
        t.setTime(+t + n)
    }
    ), ( (t, n) => n - t));
    ai.every = t => (t = Math.floor(t),
    isFinite(t) && t > 0 ? t > 1 ? oi((n => {
        n.setTime(Math.floor(n / t) * t)
    }
    ), ( (n, e) => {
        n.setTime(+n + e * t)
    }
    ), ( (n, e) => (e - n) / t)) : ai : null),
    ai.range;
    const ui = 1e3
      , li = 60 * ui
      , si = 60 * li
      , ci = 24 * si
      , fi = 7 * ci
      , hi = 30 * ci
      , pi = 365 * ci
      , di = oi((t => {
        t.setTime(t - t.getMilliseconds())
    }
    ), ( (t, n) => {
        t.setTime(+t + n * ui)
    }
    ), ( (t, n) => (n - t) / ui), (t => t.getUTCSeconds()));
    di.range;
    const yi = oi((t => {
        t.setTime(t - t.getMilliseconds() - t.getSeconds() * ui)
    }
    ), ( (t, n) => {
        t.setTime(+t + n * li)
    }
    ), ( (t, n) => (n - t) / li), (t => t.getMinutes()));
    yi.range;
    const gi = oi((t => {
        t.setUTCSeconds(0, 0)
    }
    ), ( (t, n) => {
        t.setTime(+t + n * li)
    }
    ), ( (t, n) => (n - t) / li), (t => t.getUTCMinutes()));
    gi.range;
    const vi = oi((t => {
        t.setTime(t - t.getMilliseconds() - t.getSeconds() * ui - t.getMinutes() * li)
    }
    ), ( (t, n) => {
        t.setTime(+t + n * si)
    }
    ), ( (t, n) => (n - t) / si), (t => t.getHours()));
    vi.range;
    const mi = oi((t => {
        t.setUTCMinutes(0, 0, 0)
    }
    ), ( (t, n) => {
        t.setTime(+t + n * si)
    }
    ), ( (t, n) => (n - t) / si), (t => t.getUTCHours()));
    mi.range;
    const _i = oi((t => t.setHours(0, 0, 0, 0)), ( (t, n) => t.setDate(t.getDate() + n)), ( (t, n) => (n - t - (n.getTimezoneOffset() - t.getTimezoneOffset()) * li) / ci), (t => t.getDate() - 1));
    _i.range;
    const wi = oi((t => {
        t.setUTCHours(0, 0, 0, 0)
    }
    ), ( (t, n) => {
        t.setUTCDate(t.getUTCDate() + n)
    }
    ), ( (t, n) => (n - t) / ci), (t => t.getUTCDate() - 1));
    wi.range;
    const bi = oi((t => {
        t.setUTCHours(0, 0, 0, 0)
    }
    ), ( (t, n) => {
        t.setUTCDate(t.getUTCDate() + n)
    }
    ), ( (t, n) => (n - t) / ci), (t => Math.floor(t / ci)));
    function xi(t) {
        return oi((n => {
            n.setDate(n.getDate() - (n.getDay() + 7 - t) % 7),
            n.setHours(0, 0, 0, 0)
        }
        ), ( (t, n) => {
            t.setDate(t.getDate() + 7 * n)
        }
        ), ( (t, n) => (n - t - (n.getTimezoneOffset() - t.getTimezoneOffset()) * li) / fi))
    }
    bi.range;
    const Mi = xi(0)
      , Si = xi(1)
      , Ci = xi(2)
      , Ti = xi(3)
      , Ai = xi(4)
      , ki = xi(5)
      , Ei = xi(6);
    function zi(t) {
        return oi((n => {
            n.setUTCDate(n.getUTCDate() - (n.getUTCDay() + 7 - t) % 7),
            n.setUTCHours(0, 0, 0, 0)
        }
        ), ( (t, n) => {
            t.setUTCDate(t.getUTCDate() + 7 * n)
        }
        ), ( (t, n) => (n - t) / fi))
    }
    Mi.range,
    Si.range,
    Ci.range,
    Ti.range,
    Ai.range,
    ki.range,
    Ei.range;
    const $i = zi(0)
      , Di = zi(1)
      , Ni = zi(2)
      , Ui = zi(3)
      , ji = zi(4)
      , Oi = zi(5)
      , Pi = zi(6);
    $i.range,
    Di.range,
    Ni.range,
    Ui.range,
    ji.range,
    Oi.range,
    Pi.range;
    const Hi = oi((t => {
        t.setDate(1),
        t.setHours(0, 0, 0, 0)
    }
    ), ( (t, n) => {
        t.setMonth(t.getMonth() + n)
    }
    ), ( (t, n) => n.getMonth() - t.getMonth() + 12 * (n.getFullYear() - t.getFullYear())), (t => t.getMonth()));
    Hi.range;
    const Fi = oi((t => {
        t.setUTCDate(1),
        t.setUTCHours(0, 0, 0, 0)
    }
    ), ( (t, n) => {
        t.setUTCMonth(t.getUTCMonth() + n)
    }
    ), ( (t, n) => n.getUTCMonth() - t.getUTCMonth() + 12 * (n.getUTCFullYear() - t.getUTCFullYear())), (t => t.getUTCMonth()));
    Fi.range;
    const Yi = oi((t => {
        t.setMonth(0, 1),
        t.setHours(0, 0, 0, 0)
    }
    ), ( (t, n) => {
        t.setFullYear(t.getFullYear() + n)
    }
    ), ( (t, n) => n.getFullYear() - t.getFullYear()), (t => t.getFullYear()));
    Yi.every = t => isFinite(t = Math.floor(t)) && t > 0 ? oi((n => {
        n.setFullYear(Math.floor(n.getFullYear() / t) * t),
        n.setMonth(0, 1),
        n.setHours(0, 0, 0, 0)
    }
    ), ( (n, e) => {
        n.setFullYear(n.getFullYear() + e * t)
    }
    )) : null,
    Yi.range;
    const Ii = oi((t => {
        t.setUTCMonth(0, 1),
        t.setUTCHours(0, 0, 0, 0)
    }
    ), ( (t, n) => {
        t.setUTCFullYear(t.getUTCFullYear() + n)
    }
    ), ( (t, n) => n.getUTCFullYear() - t.getUTCFullYear()), (t => t.getUTCFullYear()));
    function Li(t, n, e, r, i, o) {
        const a = [[di, 1, ui], [di, 5, 5 * ui], [di, 15, 15 * ui], [di, 30, 30 * ui], [o, 1, li], [o, 5, 5 * li], [o, 15, 15 * li], [o, 30, 30 * li], [i, 1, si], [i, 3, 3 * si], [i, 6, 6 * si], [i, 12, 12 * si], [r, 1, ci], [r, 2, 2 * ci], [e, 1, fi], [n, 1, hi], [n, 3, 3 * hi], [t, 1, pi]];
        function u(n, e, r) {
            const i = Math.abs(e - n) / r
              , o = pr(( ([,,t]) => t)).right(a, i);
            if (o === a.length)
                return t.every(xr(n / pi, e / pi, r));
            if (0 === o)
                return ai.every(Math.max(xr(n, e, r), 1));
            const [u,l] = a[i / a[o - 1][2] < a[o][2] / i ? o - 1 : o];
            return u.every(l)
        }
        return [function(t, n, e) {
            const r = n < t;
            r && ([t,n] = [n, t]);
            const i = e && "function" == typeof e.range ? e : u(t, n, e)
              , o = i ? i.range(t, +n + 1) : [];
            return r ? o.reverse() : o
        }
        , u]
    }
    Ii.every = t => isFinite(t = Math.floor(t)) && t > 0 ? oi((n => {
        n.setUTCFullYear(Math.floor(n.getUTCFullYear() / t) * t),
        n.setUTCMonth(0, 1),
        n.setUTCHours(0, 0, 0, 0)
    }
    ), ( (n, e) => {
        n.setUTCFullYear(n.getUTCFullYear() + e * t)
    }
    )) : null,
    Ii.range;
    const [qi,Xi] = Li(Ii, Fi, $i, bi, mi, gi)
      , [Vi,Ri] = Li(Yi, Hi, Mi, _i, vi, yi);
    function Bi(t) {
        if (0 <= t.y && t.y < 100) {
            var n = new Date(-1,t.m,t.d,t.H,t.M,t.S,t.L);
            return n.setFullYear(t.y),
            n
        }
        return new Date(t.y,t.m,t.d,t.H,t.M,t.S,t.L)
    }
    function Zi(t) {
        if (0 <= t.y && t.y < 100) {
            var n = new Date(Date.UTC(-1, t.m, t.d, t.H, t.M, t.S, t.L));
            return n.setUTCFullYear(t.y),
            n
        }
        return new Date(Date.UTC(t.y, t.m, t.d, t.H, t.M, t.S, t.L))
    }
    function Wi(t, n, e) {
        return {
            y: t,
            m: n,
            d: e,
            H: 0,
            M: 0,
            S: 0,
            L: 0
        }
    }
    var Gi, Qi, Ji, Ki = {
        "-": "",
        _: " ",
        0: "0"
    }, to = /^\s*\d+/, no = /^%/, eo = /[\\^$*+?|[\]().{}]/g;
    function ro(t, n, e) {
        var r = t < 0 ? "-" : ""
          , i = (r ? -t : t) + ""
          , o = i.length;
        return r + (o < e ? new Array(e - o + 1).join(n) + i : i)
    }
    function io(t) {
        return t.replace(eo, "\\$&")
    }
    function oo(t) {
        return new RegExp("^(?:" + t.map(io).join("|") + ")","i")
    }
    function ao(t) {
        return new Map(t.map(( (t, n) => [t.toLowerCase(), n])))
    }
    function uo(t, n, e) {
        var r = to.exec(n.slice(e, e + 1));
        return r ? (t.w = +r[0],
        e + r[0].length) : -1
    }
    function lo(t, n, e) {
        var r = to.exec(n.slice(e, e + 1));
        return r ? (t.u = +r[0],
        e + r[0].length) : -1
    }
    function so(t, n, e) {
        var r = to.exec(n.slice(e, e + 2));
        return r ? (t.U = +r[0],
        e + r[0].length) : -1
    }
    function co(t, n, e) {
        var r = to.exec(n.slice(e, e + 2));
        return r ? (t.V = +r[0],
        e + r[0].length) : -1
    }
    function fo(t, n, e) {
        var r = to.exec(n.slice(e, e + 2));
        return r ? (t.W = +r[0],
        e + r[0].length) : -1
    }
    function ho(t, n, e) {
        var r = to.exec(n.slice(e, e + 4));
        return r ? (t.y = +r[0],
        e + r[0].length) : -1
    }
    function po(t, n, e) {
        var r = to.exec(n.slice(e, e + 2));
        return r ? (t.y = +r[0] + (+r[0] > 68 ? 1900 : 2e3),
        e + r[0].length) : -1
    }
    function yo(t, n, e) {
        var r = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(n.slice(e, e + 6));
        return r ? (t.Z = r[1] ? 0 : -(r[2] + (r[3] || "00")),
        e + r[0].length) : -1
    }
    function go(t, n, e) {
        var r = to.exec(n.slice(e, e + 1));
        return r ? (t.q = 3 * r[0] - 3,
        e + r[0].length) : -1
    }
    function vo(t, n, e) {
        var r = to.exec(n.slice(e, e + 2));
        return r ? (t.m = r[0] - 1,
        e + r[0].length) : -1
    }
    function mo(t, n, e) {
        var r = to.exec(n.slice(e, e + 2));
        return r ? (t.d = +r[0],
        e + r[0].length) : -1
    }
    function _o(t, n, e) {
        var r = to.exec(n.slice(e, e + 3));
        return r ? (t.m = 0,
        t.d = +r[0],
        e + r[0].length) : -1
    }
    function wo(t, n, e) {
        var r = to.exec(n.slice(e, e + 2));
        return r ? (t.H = +r[0],
        e + r[0].length) : -1
    }
    function bo(t, n, e) {
        var r = to.exec(n.slice(e, e + 2));
        return r ? (t.M = +r[0],
        e + r[0].length) : -1
    }
    function xo(t, n, e) {
        var r = to.exec(n.slice(e, e + 2));
        return r ? (t.S = +r[0],
        e + r[0].length) : -1
    }
    function Mo(t, n, e) {
        var r = to.exec(n.slice(e, e + 3));
        return r ? (t.L = +r[0],
        e + r[0].length) : -1
    }
    function So(t, n, e) {
        var r = to.exec(n.slice(e, e + 6));
        return r ? (t.L = Math.floor(r[0] / 1e3),
        e + r[0].length) : -1
    }
    function Co(t, n, e) {
        var r = no.exec(n.slice(e, e + 1));
        return r ? e + r[0].length : -1
    }
    function To(t, n, e) {
        var r = to.exec(n.slice(e));
        return r ? (t.Q = +r[0],
        e + r[0].length) : -1
    }
    function Ao(t, n, e) {
        var r = to.exec(n.slice(e));
        return r ? (t.s = +r[0],
        e + r[0].length) : -1
    }
    function ko(t, n) {
        return ro(t.getDate(), n, 2)
    }
    function Eo(t, n) {
        return ro(t.getHours(), n, 2)
    }
    function zo(t, n) {
        return ro(t.getHours() % 12 || 12, n, 2)
    }
    function $o(t, n) {
        return ro(1 + _i.count(Yi(t), t), n, 3)
    }
    function Do(t, n) {
        return ro(t.getMilliseconds(), n, 3)
    }
    function No(t, n) {
        return Do(t, n) + "000"
    }
    function Uo(t, n) {
        return ro(t.getMonth() + 1, n, 2)
    }
    function jo(t, n) {
        return ro(t.getMinutes(), n, 2)
    }
    function Oo(t, n) {
        return ro(t.getSeconds(), n, 2)
    }
    function Po(t) {
        var n = t.getDay();
        return 0 === n ? 7 : n
    }
    function Ho(t, n) {
        return ro(Mi.count(Yi(t) - 1, t), n, 2)
    }
    function Fo(t) {
        var n = t.getDay();
        return n >= 4 || 0 === n ? Ai(t) : Ai.ceil(t)
    }
    function Yo(t, n) {
        return t = Fo(t),
        ro(Ai.count(Yi(t), t) + (4 === Yi(t).getDay()), n, 2)
    }
    function Io(t) {
        return t.getDay()
    }
    function Lo(t, n) {
        return ro(Si.count(Yi(t) - 1, t), n, 2)
    }
    function qo(t, n) {
        return ro(t.getFullYear() % 100, n, 2)
    }
    function Xo(t, n) {
        return ro((t = Fo(t)).getFullYear() % 100, n, 2)
    }
    function Vo(t, n) {
        return ro(t.getFullYear() % 1e4, n, 4)
    }
    function Ro(t, n) {
        var e = t.getDay();
        return ro((t = e >= 4 || 0 === e ? Ai(t) : Ai.ceil(t)).getFullYear() % 1e4, n, 4)
    }
    function Bo(t) {
        var n = t.getTimezoneOffset();
        return (n > 0 ? "-" : (n *= -1,
        "+")) + ro(n / 60 | 0, "0", 2) + ro(n % 60, "0", 2)
    }
    function Zo(t, n) {
        return ro(t.getUTCDate(), n, 2)
    }
    function Wo(t, n) {
        return ro(t.getUTCHours(), n, 2)
    }
    function Go(t, n) {
        return ro(t.getUTCHours() % 12 || 12, n, 2)
    }
    function Qo(t, n) {
        return ro(1 + wi.count(Ii(t), t), n, 3)
    }
    function Jo(t, n) {
        return ro(t.getUTCMilliseconds(), n, 3)
    }
    function Ko(t, n) {
        return Jo(t, n) + "000"
    }
    function ta(t, n) {
        return ro(t.getUTCMonth() + 1, n, 2)
    }
    function na(t, n) {
        return ro(t.getUTCMinutes(), n, 2)
    }
    function ea(t, n) {
        return ro(t.getUTCSeconds(), n, 2)
    }
    function ra(t) {
        var n = t.getUTCDay();
        return 0 === n ? 7 : n
    }
    function ia(t, n) {
        return ro($i.count(Ii(t) - 1, t), n, 2)
    }
    function oa(t) {
        var n = t.getUTCDay();
        return n >= 4 || 0 === n ? ji(t) : ji.ceil(t)
    }
    function aa(t, n) {
        return t = oa(t),
        ro(ji.count(Ii(t), t) + (4 === Ii(t).getUTCDay()), n, 2)
    }
    function ua(t) {
        return t.getUTCDay()
    }
    function la(t, n) {
        return ro(Di.count(Ii(t) - 1, t), n, 2)
    }
    function sa(t, n) {
        return ro(t.getUTCFullYear() % 100, n, 2)
    }
    function ca(t, n) {
        return ro((t = oa(t)).getUTCFullYear() % 100, n, 2)
    }
    function fa(t, n) {
        return ro(t.getUTCFullYear() % 1e4, n, 4)
    }
    function ha(t, n) {
        var e = t.getUTCDay();
        return ro((t = e >= 4 || 0 === e ? ji(t) : ji.ceil(t)).getUTCFullYear() % 1e4, n, 4)
    }
    function pa() {
        return "+0000"
    }
    function da() {
        return "%"
    }
    function ya(t) {
        return +t
    }
    function ga(t) {
        return Math.floor(+t / 1e3)
    }
    function va(t) {
        return new Date(t)
    }
    function ma(t) {
        return t instanceof Date ? +t : +new Date(+t)
    }
    function _a(t, n, e, r, i, o, a, u, l, s) {
        var c = Nr()
          , f = c.invert
          , h = c.domain
          , p = s(".%L")
          , d = s(":%S")
          , y = s("%I:%M")
          , g = s("%I %p")
          , v = s("%a %d")
          , m = s("%b %d")
          , _ = s("%B")
          , w = s("%Y");
        function b(t) {
            return (l(t) < t ? p : u(t) < t ? d : a(t) < t ? y : o(t) < t ? g : r(t) < t ? i(t) < t ? v : m : e(t) < t ? _ : w)(t)
        }
        return c.invert = function(t) {
            return new Date(f(t))
        }
        ,
        c.domain = function(t) {
            return arguments.length ? h(Array.from(t, ma)) : h().map(va)
        }
        ,
        c.ticks = function(n) {
            var e = h();
            return t(e[0], e[e.length - 1], null == n ? 10 : n)
        }
        ,
        c.tickFormat = function(t, n) {
            return null == n ? b : s(n)
        }
        ,
        c.nice = function(t) {
            var e = h();
            return t && "function" == typeof t.range || (t = n(e[0], e[e.length - 1], null == t ? 10 : t)),
            t ? h(function(t, n) {
                var e, r = 0, i = (t = t.slice()).length - 1, o = t[r], a = t[i];
                return a < o && (e = r,
                r = i,
                i = e,
                e = o,
                o = a,
                a = e),
                t[r] = n.floor(o),
                t[i] = n.ceil(a),
                t
            }(e, t)) : c
        }
        ,
        c.copy = function() {
            return $r(c, _a(t, n, e, r, i, o, a, u, l, s))
        }
        ,
        c
    }
    function wa() {
        return Sr.apply(_a(Vi, Ri, Yi, Hi, Mi, _i, vi, yi, di, Qi).domain([new Date(2e3,0,1), new Date(2e3,0,2)]), arguments)
    }
    function ba() {
        return Sr.apply(_a(qi, Xi, Ii, Fi, $i, wi, mi, gi, di, Ji).domain([Date.UTC(2e3, 0, 1), Date.UTC(2e3, 0, 2)]), arguments)
    }
    function xa(t) {
        return function() {
            return t
        }
    }
    !function(t) {
        Gi = function(t) {
            var n = t.dateTime
              , e = t.date
              , r = t.time
              , i = t.periods
              , o = t.days
              , a = t.shortDays
              , u = t.months
              , l = t.shortMonths
              , s = oo(i)
              , c = ao(i)
              , f = oo(o)
              , h = ao(o)
              , p = oo(a)
              , d = ao(a)
              , y = oo(u)
              , g = ao(u)
              , v = oo(l)
              , m = ao(l)
              , _ = {
                a: function(t) {
                    return a[t.getDay()]
                },
                A: function(t) {
                    return o[t.getDay()]
                },
                b: function(t) {
                    return l[t.getMonth()]
                },
                B: function(t) {
                    return u[t.getMonth()]
                },
                c: null,
                d: ko,
                e: ko,
                f: No,
                g: Xo,
                G: Ro,
                H: Eo,
                I: zo,
                j: $o,
                L: Do,
                m: Uo,
                M: jo,
                p: function(t) {
                    return i[+(t.getHours() >= 12)]
                },
                q: function(t) {
                    return 1 + ~~(t.getMonth() / 3)
                },
                Q: ya,
                s: ga,
                S: Oo,
                u: Po,
                U: Ho,
                V: Yo,
                w: Io,
                W: Lo,
                x: null,
                X: null,
                y: qo,
                Y: Vo,
                Z: Bo,
                "%": da
            }
              , w = {
                a: function(t) {
                    return a[t.getUTCDay()]
                },
                A: function(t) {
                    return o[t.getUTCDay()]
                },
                b: function(t) {
                    return l[t.getUTCMonth()]
                },
                B: function(t) {
                    return u[t.getUTCMonth()]
                },
                c: null,
                d: Zo,
                e: Zo,
                f: Ko,
                g: ca,
                G: ha,
                H: Wo,
                I: Go,
                j: Qo,
                L: Jo,
                m: ta,
                M: na,
                p: function(t) {
                    return i[+(t.getUTCHours() >= 12)]
                },
                q: function(t) {
                    return 1 + ~~(t.getUTCMonth() / 3)
                },
                Q: ya,
                s: ga,
                S: ea,
                u: ra,
                U: ia,
                V: aa,
                w: ua,
                W: la,
                x: null,
                X: null,
                y: sa,
                Y: fa,
                Z: pa,
                "%": da
            }
              , b = {
                a: function(t, n, e) {
                    var r = p.exec(n.slice(e));
                    return r ? (t.w = d.get(r[0].toLowerCase()),
                    e + r[0].length) : -1
                },
                A: function(t, n, e) {
                    var r = f.exec(n.slice(e));
                    return r ? (t.w = h.get(r[0].toLowerCase()),
                    e + r[0].length) : -1
                },
                b: function(t, n, e) {
                    var r = v.exec(n.slice(e));
                    return r ? (t.m = m.get(r[0].toLowerCase()),
                    e + r[0].length) : -1
                },
                B: function(t, n, e) {
                    var r = y.exec(n.slice(e));
                    return r ? (t.m = g.get(r[0].toLowerCase()),
                    e + r[0].length) : -1
                },
                c: function(t, e, r) {
                    return S(t, n, e, r)
                },
                d: mo,
                e: mo,
                f: So,
                g: po,
                G: ho,
                H: wo,
                I: wo,
                j: _o,
                L: Mo,
                m: vo,
                M: bo,
                p: function(t, n, e) {
                    var r = s.exec(n.slice(e));
                    return r ? (t.p = c.get(r[0].toLowerCase()),
                    e + r[0].length) : -1
                },
                q: go,
                Q: To,
                s: Ao,
                S: xo,
                u: lo,
                U: so,
                V: co,
                w: uo,
                W: fo,
                x: function(t, n, r) {
                    return S(t, e, n, r)
                },
                X: function(t, n, e) {
                    return S(t, r, n, e)
                },
                y: po,
                Y: ho,
                Z: yo,
                "%": Co
            };
            function x(t, n) {
                return function(e) {
                    var r, i, o, a = [], u = -1, l = 0, s = t.length;
                    for (e instanceof Date || (e = new Date(+e)); ++u < s; )
                        37 === t.charCodeAt(u) && (a.push(t.slice(l, u)),
                        null != (i = Ki[r = t.charAt(++u)]) ? r = t.charAt(++u) : i = "e" === r ? " " : "0",
                        (o = n[r]) && (r = o(e, i)),
                        a.push(r),
                        l = u + 1);
                    return a.push(t.slice(l, u)),
                    a.join("")
                }
            }
            function M(t, n) {
                return function(e) {
                    var r, i, o = Wi(1900, void 0, 1);
                    if (S(o, t, e += "", 0) != e.length)
                        return null;
                    if ("Q"in o)
                        return new Date(o.Q);
                    if ("s"in o)
                        return new Date(1e3 * o.s + ("L"in o ? o.L : 0));
                    if (n && !("Z"in o) && (o.Z = 0),
                    "p"in o && (o.H = o.H % 12 + 12 * o.p),
                    void 0 === o.m && (o.m = "q"in o ? o.q : 0),
                    "V"in o) {
                        if (o.V < 1 || o.V > 53)
                            return null;
                        "w"in o || (o.w = 1),
                        "Z"in o ? (i = (r = Zi(Wi(o.y, 0, 1))).getUTCDay(),
                        r = i > 4 || 0 === i ? Di.ceil(r) : Di(r),
                        r = wi.offset(r, 7 * (o.V - 1)),
                        o.y = r.getUTCFullYear(),
                        o.m = r.getUTCMonth(),
                        o.d = r.getUTCDate() + (o.w + 6) % 7) : (i = (r = Bi(Wi(o.y, 0, 1))).getDay(),
                        r = i > 4 || 0 === i ? Si.ceil(r) : Si(r),
                        r = _i.offset(r, 7 * (o.V - 1)),
                        o.y = r.getFullYear(),
                        o.m = r.getMonth(),
                        o.d = r.getDate() + (o.w + 6) % 7)
                    } else
                        ("W"in o || "U"in o) && ("w"in o || (o.w = "u"in o ? o.u % 7 : "W"in o ? 1 : 0),
                        i = "Z"in o ? Zi(Wi(o.y, 0, 1)).getUTCDay() : Bi(Wi(o.y, 0, 1)).getDay(),
                        o.m = 0,
                        o.d = "W"in o ? (o.w + 6) % 7 + 7 * o.W - (i + 5) % 7 : o.w + 7 * o.U - (i + 6) % 7);
                    return "Z"in o ? (o.H += o.Z / 100 | 0,
                    o.M += o.Z % 100,
                    Zi(o)) : Bi(o)
                }
            }
            function S(t, n, e, r) {
                for (var i, o, a = 0, u = n.length, l = e.length; a < u; ) {
                    if (r >= l)
                        return -1;
                    if (37 === (i = n.charCodeAt(a++))) {
                        if (i = n.charAt(a++),
                        !(o = b[i in Ki ? n.charAt(a++) : i]) || (r = o(t, e, r)) < 0)
                            return -1
                    } else if (i != e.charCodeAt(r++))
                        return -1
                }
                return r
            }
            return _.x = x(e, _),
            _.X = x(r, _),
            _.c = x(n, _),
            w.x = x(e, w),
            w.X = x(r, w),
            w.c = x(n, w),
            {
                format: function(t) {
                    var n = x(t += "", _);
                    return n.toString = function() {
                        return t
                    }
                    ,
                    n
                },
                parse: function(t) {
                    var n = M(t += "", !1);
                    return n.toString = function() {
                        return t
                    }
                    ,
                    n
                },
                utcFormat: function(t) {
                    var n = x(t += "", w);
                    return n.toString = function() {
                        return t
                    }
                    ,
                    n
                },
                utcParse: function(t) {
                    var n = M(t += "", !0);
                    return n.toString = function() {
                        return t
                    }
                    ,
                    n
                }
            }
        }(t),
        Qi = Gi.format,
        Gi.parse,
        Ji = Gi.utcFormat,
        Gi.utcParse
    }({
        dateTime: "%x, %X",
        date: "%-m/%-d/%Y",
        time: "%-I:%M:%S %p",
        periods: ["AM", "PM"],
        days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    });
    const Ma = Math.PI
      , Sa = 2 * Ma
      , Ca = 1e-6
      , Ta = Sa - Ca;
    function Aa(t) {
        this._ += t[0];
        for (let n = 1, e = t.length; n < e; ++n)
            this._ += arguments[n] + t[n]
    }
    class ka {
        constructor(t) {
            this._x0 = this._y0 = this._x1 = this._y1 = null,
            this._ = "",
            this._append = null == t ? Aa : function(t) {
                let n = Math.floor(t);
                if (!(n >= 0))
                    throw new Error(`invalid digits: ${t}`);
                if (n > 15)
                    return Aa;
                const e = 10 ** n;
                return function(t) {
                    this._ += t[0];
                    for (let n = 1, r = t.length; n < r; ++n)
                        this._ += Math.round(arguments[n] * e) / e + t[n]
                }
            }(t)
        }
        moveTo(t, n) {
            this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +n}`
        }
        closePath() {
            null !== this._x1 && (this._x1 = this._x0,
            this._y1 = this._y0,
            this._append`Z`)
        }
        lineTo(t, n) {
            this._append`L${this._x1 = +t},${this._y1 = +n}`
        }
        quadraticCurveTo(t, n, e, r) {
            this._append`Q${+t},${+n},${this._x1 = +e},${this._y1 = +r}`
        }
        bezierCurveTo(t, n, e, r, i, o) {
            this._append`C${+t},${+n},${+e},${+r},${this._x1 = +i},${this._y1 = +o}`
        }
        arcTo(t, n, e, r, i) {
            if (t = +t,
            n = +n,
            e = +e,
            r = +r,
            (i = +i) < 0)
                throw new Error(`negative radius: ${i}`);
            let o = this._x1
              , a = this._y1
              , u = e - t
              , l = r - n
              , s = o - t
              , c = a - n
              , f = s * s + c * c;
            if (null === this._x1)
                this._append`M${this._x1 = t},${this._y1 = n}`;
            else if (f > Ca)
                if (Math.abs(c * u - l * s) > Ca && i) {
                    let h = e - o
                      , p = r - a
                      , d = u * u + l * l
                      , y = h * h + p * p
                      , g = Math.sqrt(d)
                      , v = Math.sqrt(f)
                      , m = i * Math.tan((Ma - Math.acos((d + f - y) / (2 * g * v))) / 2)
                      , _ = m / v
                      , w = m / g;
                    Math.abs(_ - 1) > Ca && this._append`L${t + _ * s},${n + _ * c}`,
                    this._append`A${i},${i},0,0,${+(c * h > s * p)},${this._x1 = t + w * u},${this._y1 = n + w * l}`
                } else
                    this._append`L${this._x1 = t},${this._y1 = n}`;
            else
                ;
        }
        arc(t, n, e, r, i, o) {
            if (t = +t,
            n = +n,
            o = !!o,
            (e = +e) < 0)
                throw new Error(`negative radius: ${e}`);
            let a = e * Math.cos(r)
              , u = e * Math.sin(r)
              , l = t + a
              , s = n + u
              , c = 1 ^ o
              , f = o ? r - i : i - r;
            null === this._x1 ? this._append`M${l},${s}` : (Math.abs(this._x1 - l) > Ca || Math.abs(this._y1 - s) > Ca) && this._append`L${l},${s}`,
            e && (f < 0 && (f = f % Sa + Sa),
            f > Ta ? this._append`A${e},${e},0,1,${c},${t - a},${n - u}A${e},${e},0,1,${c},${this._x1 = l},${this._y1 = s}` : f > Ca && this._append`A${e},${e},0,${+(f >= Ma)},${c},${this._x1 = t + e * Math.cos(i)},${this._y1 = n + e * Math.sin(i)}`)
        }
        rect(t, n, e, r) {
            this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +n}h${e = +e}v${+r}h${-e}Z`
        }
        toString() {
            return this._
        }
    }
    function Ea(t) {
        let n = 3;
        return t.digits = function(e) {
            if (!arguments.length)
                return n;
            if (null == e)
                n = null;
            else {
                const t = Math.floor(e);
                if (!(t >= 0))
                    throw new RangeError(`invalid digits: ${e}`);
                n = t
            }
            return t
        }
        ,
        () => new ka(n)
    }
    function za(t) {
        return "object" == typeof t && "length"in t ? t : Array.from(t)
    }
    function $a(t) {
        this._context = t
    }
    function Da(t) {
        return new $a(t)
    }
    function Na(t) {
        return t[0]
    }
    function Ua(t) {
        return t[1]
    }
    function ja(t, n, e) {
        var r = null
          , i = xa(!0)
          , o = null
          , a = Da
          , u = null
          , l = Ea(s);
        function s(s) {
            var c, f, h, p, d, y = (s = za(s)).length, g = !1, v = new Array(y), m = new Array(y);
            for (null == o && (u = a(d = l())),
            c = 0; c <= y; ++c) {
                if (!(c < y && i(p = s[c], c, s)) === g)
                    if (g = !g)
                        f = c,
                        u.areaStart(),
                        u.lineStart();
                    else {
                        for (u.lineEnd(),
                        u.lineStart(),
                        h = c - 1; h >= f; --h)
                            u.point(v[h], m[h]);
                        u.lineEnd(),
                        u.areaEnd()
                    }
                g && (v[c] = +t(p, c, s),
                m[c] = +n(p, c, s),
                u.point(r ? +r(p, c, s) : v[c], e ? +e(p, c, s) : m[c]))
            }
            if (d)
                return u = null,
                d + "" || null
        }
        function c() {
            return function(t, n) {
                var e = xa(!0)
                  , r = null
                  , i = Da
                  , o = null
                  , a = Ea(u);
                function u(u) {
                    var l, s, c, f = (u = za(u)).length, h = !1;
                    for (null == r && (o = i(c = a())),
                    l = 0; l <= f; ++l)
                        !(l < f && e(s = u[l], l, u)) === h && ((h = !h) ? o.lineStart() : o.lineEnd()),
                        h && o.point(+t(s, l, u), +n(s, l, u));
                    if (c)
                        return o = null,
                        c + "" || null
                }
                return t = "function" == typeof t ? t : void 0 === t ? Na : xa(t),
                n = "function" == typeof n ? n : void 0 === n ? Ua : xa(n),
                u.x = function(n) {
                    return arguments.length ? (t = "function" == typeof n ? n : xa(+n),
                    u) : t
                }
                ,
                u.y = function(t) {
                    return arguments.length ? (n = "function" == typeof t ? t : xa(+t),
                    u) : n
                }
                ,
                u.defined = function(t) {
                    return arguments.length ? (e = "function" == typeof t ? t : xa(!!t),
                    u) : e
                }
                ,
                u.curve = function(t) {
                    return arguments.length ? (i = t,
                    null != r && (o = i(r)),
                    u) : i
                }
                ,
                u.context = function(t) {
                    return arguments.length ? (null == t ? r = o = null : o = i(r = t),
                    u) : r
                }
                ,
                u
            }().defined(i).curve(a).context(o)
        }
        return t = "function" == typeof t ? t : void 0 === t ? Na : xa(+t),
        n = "function" == typeof n ? n : xa(void 0 === n ? 0 : +n),
        e = "function" == typeof e ? e : void 0 === e ? Ua : xa(+e),
        s.x = function(n) {
            return arguments.length ? (t = "function" == typeof n ? n : xa(+n),
            r = null,
            s) : t
        }
        ,
        s.x0 = function(n) {
            return arguments.length ? (t = "function" == typeof n ? n : xa(+n),
            s) : t
        }
        ,
        s.x1 = function(t) {
            return arguments.length ? (r = null == t ? null : "function" == typeof t ? t : xa(+t),
            s) : r
        }
        ,
        s.y = function(t) {
            return arguments.length ? (n = "function" == typeof t ? t : xa(+t),
            e = null,
            s) : n
        }
        ,
        s.y0 = function(t) {
            return arguments.length ? (n = "function" == typeof t ? t : xa(+t),
            s) : n
        }
        ,
        s.y1 = function(t) {
            return arguments.length ? (e = null == t ? null : "function" == typeof t ? t : xa(+t),
            s) : e
        }
        ,
        s.lineX0 = s.lineY0 = function() {
            return c().x(t).y(n)
        }
        ,
        s.lineY1 = function() {
            return c().x(t).y(e)
        }
        ,
        s.lineX1 = function() {
            return c().x(r).y(n)
        }
        ,
        s.defined = function(t) {
            return arguments.length ? (i = "function" == typeof t ? t : xa(!!t),
            s) : i
        }
        ,
        s.curve = function(t) {
            return arguments.length ? (a = t,
            null != o && (u = a(o)),
            s) : a
        }
        ,
        s.context = function(t) {
            return arguments.length ? (null == t ? o = u = null : u = a(o = t),
            s) : o
        }
        ,
        s
    }
    function Oa(t, n, e) {
        t._context.bezierCurveTo((2 * t._x0 + t._x1) / 3, (2 * t._y0 + t._y1) / 3, (t._x0 + 2 * t._x1) / 3, (t._y0 + 2 * t._y1) / 3, (t._x0 + 4 * t._x1 + n) / 6, (t._y0 + 4 * t._y1 + e) / 6)
    }
    function Pa(t) {
        this._context = t
    }
    function Ha(t) {
        return new Pa(t)
    }
    $a.prototype = {
        areaStart: function() {
            this._line = 0
        },
        areaEnd: function() {
            this._line = NaN
        },
        lineStart: function() {
            this._point = 0
        },
        lineEnd: function() {
            (this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(),
            this._line = 1 - this._line
        },
        point: function(t, n) {
            switch (t = +t,
            n = +n,
            this._point) {
            case 0:
                this._point = 1,
                this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                break;
            case 1:
                this._point = 2;
            default:
                this._context.lineTo(t, n)
            }
        }
    },
    Pa.prototype = {
        areaStart: function() {
            this._line = 0
        },
        areaEnd: function() {
            this._line = NaN
        },
        lineStart: function() {
            this._x0 = this._x1 = this._y0 = this._y1 = NaN,
            this._point = 0
        },
        lineEnd: function() {
            switch (this._point) {
            case 3:
                Oa(this, this._x1, this._y1);
            case 2:
                this._context.lineTo(this._x1, this._y1)
            }
            (this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(),
            this._line = 1 - this._line
        },
        point: function(t, n) {
            switch (t = +t,
            n = +n,
            this._point) {
            case 0:
                this._point = 1,
                this._line ? this._context.lineTo(t, n) : this._context.moveTo(t, n);
                break;
            case 1:
                this._point = 2;
                break;
            case 2:
                this._point = 3,
                this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
            default:
                Oa(this, t, n)
            }
            this._x0 = this._x1,
            this._x1 = t,
            this._y0 = this._y1,
            this._y1 = n
        }
    };
    var Fa = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
    function Ya(t, n, e) {
        var r, i, o, a, u;
        function l() {
            var s = Date.now() - a;
            s < n && s >= 0 ? r = setTimeout(l, n - s) : (r = null,
            e || (u = t.apply(o, i),
            o = i = null))
        }
        null == n && (n = 100);
        var s = function() {
            o = this,
            i = arguments,
            a = Date.now();
            var s = e && !r;
            return r || (r = setTimeout(l, n)),
            s && (u = t.apply(o, i),
            o = i = null),
            u
        };
        return s.clear = function() {
            r && (clearTimeout(r),
            r = null)
        }
        ,
        s.flush = function() {
            r && (u = t.apply(o, i),
            o = i = null,
            clearTimeout(r),
            r = null)
        }
        ,
        s
    }
    Ya.debounce = Ya;
    var Ia = Ya;
    function La(t, n) {
        for (var e = 0; e < n.length; e++) {
            var r = n[e];
            r.enumerable = r.enumerable || !1,
            r.configurable = !0,
            "value"in r && (r.writable = !0),
            Object.defineProperty(t, (i = r.key,
            o = void 0,
            "symbol" == typeof (o = function(t, n) {
                if ("object" != typeof t || null === t)
                    return t;
                var e = t[Symbol.toPrimitive];
                if (void 0 !== e) {
                    var r = e.call(t, n || "default");
                    if ("object" != typeof r)
                        return r;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return ("string" === n ? String : Number)(t)
            }(i, "string")) ? o : String(o)), r)
        }
        var i, o
    }
    function qa(t, n, e) {
        return n && La(t.prototype, n),
        e && La(t, e),
        Object.defineProperty(t, "prototype", {
            writable: !1
        }),
        t
    }
    function Xa(t, n) {
        return function(t) {
            if (Array.isArray(t))
                return t
        }(t) || function(t, n) {
            var e = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (null != e) {
                var r, i, o, a, u = [], l = !0, s = !1;
                try {
                    if (o = (e = e.call(t)).next,
                    0 === n) {
                        if (Object(e) !== e)
                            return;
                        l = !1
                    } else
                        for (; !(l = (r = o.call(e)).done) && (u.push(r.value),
                        u.length !== n); l = !0)
                            ;
                } catch (t) {
                    s = !0,
                    i = t
                } finally {
                    try {
                        if (!l && null != e.return && (a = e.return(),
                        Object(a) !== a))
                            return
                    } finally {
                        if (s)
                            throw i
                    }
                }
                return u
            }
        }(t, n) || function(t, n) {
            if (!t)
                return;
            if ("string" == typeof t)
                return Va(t, n);
            var e = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === e && t.constructor && (e = t.constructor.name);
            if ("Map" === e || "Set" === e)
                return Array.from(t);
            if ("Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e))
                return Va(t, n)
        }(t, n) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }
    function Va(t, n) {
        (null == n || n > t.length) && (n = t.length);
        for (var e = 0, r = new Array(n); e < n; e++)
            r[e] = t[e];
        return r
    }
    var Ra = qa((function t(n, e) {
        var r = e.default
          , i = void 0 === r ? null : r
          , o = e.triggerUpdate
          , a = void 0 === o || o
          , u = e.onChange
          , l = void 0 === u ? function(t, n) {}
        : u;
        !function(t, n) {
            if (!(t instanceof n))
                throw new TypeError("Cannot call a class as a function")
        }(this, t),
        this.name = n,
        this.defaultVal = i,
        this.triggerUpdate = a,
        this.onChange = l
    }
    ));
    function Ba(t) {
        var n = t.stateInit
          , e = void 0 === n ? function() {
            return {}
        }
        : n
          , r = t.props
          , i = void 0 === r ? {} : r
          , o = t.methods
          , a = void 0 === o ? {} : o
          , u = t.aliases
          , l = void 0 === u ? {} : u
          , s = t.init
          , c = void 0 === s ? function() {}
        : s
          , f = t.update
          , h = void 0 === f ? function() {}
        : f
          , p = Object.keys(i).map((function(t) {
            return new Ra(t,i[t])
        }
        ));
        return function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}
              , n = Object.assign({}, e instanceof Function ? e(t) : e, {
                initialised: !1
            })
              , r = {};
            function i(n) {
                return o(n, t),
                u(),
                i
            }
            var o = function(t, e) {
                c.call(i, t, n, e),
                n.initialised = !0
            }
              , u = Ia((function() {
                n.initialised && (h.call(i, n, r),
                r = {})
            }
            ), 1);
            return p.forEach((function(t) {
                i[t.name] = function(t) {
                    var e = t.name
                      , o = t.triggerUpdate
                      , a = void 0 !== o && o
                      , l = t.onChange
                      , s = void 0 === l ? function(t, n) {}
                    : l
                      , c = t.defaultVal
                      , f = void 0 === c ? null : c;
                    return function(t) {
                        var o = n[e];
                        if (!arguments.length)
                            return o;
                        var l = void 0 === t ? f : t;
                        return n[e] = l,
                        s.call(i, l, n, o),
                        !r.hasOwnProperty(e) && (r[e] = o),
                        a && u(),
                        i
                    }
                }(t)
            }
            )),
            Object.keys(a).forEach((function(t) {
                i[t] = function() {
                    for (var e, r = arguments.length, o = new Array(r), u = 0; u < r; u++)
                        o[u] = arguments[u];
                    return (e = a[t]).call.apply(e, [i, n].concat(o))
                }
            }
            )),
            Object.entries(l).forEach((function(t) {
                var n = Xa(t, 2)
                  , e = n[0]
                  , r = n[1];
                return i[e] = i[r]
            }
            )),
            i.resetProps = function() {
                return p.forEach((function(t) {
                    i[t.name](t.defaultVal)
                }
                )),
                i
            }
            ,
            i.resetProps(),
            n._rerender = u,
            i
        }
    }
    var Za = function(t) {
        return t instanceof Function ? t : "string" == typeof t ? function(n) {
            return n[t]
        }
        : function(n) {
            return t
        }
    };
    function Wa(t, n) {
        if (null == t)
            return {};
        var e, r, i = function(t, n) {
            if (null == t)
                return {};
            var e, r, i = {}, o = Object.keys(t);
            for (r = 0; r < o.length; r++)
                e = o[r],
                n.indexOf(e) >= 0 || (i[e] = t[e]);
            return i
        }(t, n);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(t);
            for (r = 0; r < o.length; r++)
                e = o[r],
                n.indexOf(e) >= 0 || Object.prototype.propertyIsEnumerable.call(t, e) && (i[e] = t[e])
        }
        return i
    }
    function Ga(t, n) {
        return function(t) {
            if (Array.isArray(t))
                return t
        }(t) || function(t, n) {
            var e = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (null != e) {
                var r, i, o, a, u = [], l = !0, s = !1;
                try {
                    if (o = (e = e.call(t)).next,
                    0 === n) {
                        if (Object(e) !== e)
                            return;
                        l = !1
                    } else
                        for (; !(l = (r = o.call(e)).done) && (u.push(r.value),
                        u.length !== n); l = !0)
                            ;
                } catch (t) {
                    s = !0,
                    i = t
                } finally {
                    try {
                        if (!l && null != e.return && (a = e.return(),
                        Object(a) !== a))
                            return
                    } finally {
                        if (s)
                            throw i
                    }
                }
                return u
            }
        }(t, n) || Ja(t, n) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }
    function Qa(t) {
        return function(t) {
            if (Array.isArray(t))
                return Ka(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"])
                return Array.from(t)
        }(t) || Ja(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }
    function Ja(t, n) {
        if (t) {
            if ("string" == typeof t)
                return Ka(t, n);
            var e = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === e && t.constructor && (e = t.constructor.name),
            "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? Ka(t, n) : void 0
        }
    }
    function Ka(t, n) {
        (null == n || n > t.length) && (n = t.length);
        for (var e = 0, r = new Array(n); e < n; e++)
            r[e] = t[e];
        return r
    }
    function tu(t) {
        var n = function(t, n) {
            if ("object" != typeof t || null === t)
                return t;
            var e = t[Symbol.toPrimitive];
            if (void 0 !== e) {
                var r = e.call(t, n || "default");
                if ("object" != typeof r)
                    return r;
                throw new TypeError("@@toPrimitive must return a primitive value.")
            }
            return ("string" === n ? String : Number)(t)
        }(t, "string");
        return "symbol" == typeof n ? n : String(n)
    }
    var nu = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : []
          , n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : []
          , e = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2]
          , r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3]
          , i = (n instanceof Array ? n.length ? n : [void 0] : [n]).map((function(t) {
            return {
                keyAccessor: t,
                isProp: !(t instanceof Function)
            }
        }
        ))
          , o = t.reduce((function(t, n) {
            var r = t
              , o = n;
            return i.forEach((function(t, n) {
                var a, u = t.keyAccessor;
                if (t.isProp) {
                    var l = o
                      , s = l[u]
                      , c = Wa(l, [u].map(tu));
                    a = s,
                    o = c
                } else
                    a = u(o, n);
                n + 1 < i.length ? (r.hasOwnProperty(a) || (r[a] = {}),
                r = r[a]) : e ? (r.hasOwnProperty(a) || (r[a] = []),
                r[a].push(o)) : r[a] = o
            }
            )),
            t
        }
        ), {});
        e instanceof Function && function t(n) {
            var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
            r === i.length ? Object.keys(n).forEach((function(t) {
                return n[t] = e(n[t])
            }
            )) : Object.values(n).forEach((function(n) {
                return t(n, r + 1)
            }
            ))
        }(o);
        var a = o;
        return r && (a = [],
        function t(n) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
            e.length === i.length ? a.push({
                keys: e,
                vals: n
            }) : Object.entries(n).forEach((function(n) {
                var r = Ga(n, 2)
                  , i = r[0]
                  , o = r[1];
                return t(o, [].concat(Qa(e), [i]))
            }
            ))
        }(o),
        n instanceof Array && 0 === n.length && 1 === a.length && (a[0].keys = [])),
        a
    };
    function eu(t) {
        return eu = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        }
        : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        }
        ,
        eu(t)
    }
    function ru(t, n) {
        return function(t) {
            if (Array.isArray(t))
                return t
        }(t) || function(t, n) {
            var e = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
            if (null != e) {
                var r, i, o, a, u = [], l = !0, s = !1;
                try {
                    if (o = (e = e.call(t)).next,
                    0 === n) {
                        if (Object(e) !== e)
                            return;
                        l = !1
                    } else
                        for (; !(l = (r = o.call(e)).done) && (u.push(r.value),
                        u.length !== n); l = !0)
                            ;
                } catch (t) {
                    s = !0,
                    i = t
                } finally {
                    try {
                        if (!l && null != e.return && (a = e.return(),
                        Object(a) !== a))
                            return
                    } finally {
                        if (s)
                            throw i
                    }
                }
                return u
            }
        }(t, n) || ou(t, n) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }
    function iu(t) {
        return function(t) {
            if (Array.isArray(t))
                return au(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"])
                return Array.from(t)
        }(t) || ou(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }
    function ou(t, n) {
        if (t) {
            if ("string" == typeof t)
                return au(t, n);
            var e = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === e && t.constructor && (e = t.constructor.name),
            "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? au(t, n) : void 0
        }
    }
    function au(t, n) {
        (null == n || n > t.length) && (n = t.length);
        for (var e = 0, r = new Array(n); e < n; e++)
            r[e] = t[e];
        return r
    }
    !function(t, n) {
        void 0 === n && (n = {});
        var e = n.insertAt;
        if (t && "undefined" != typeof document) {
            var r = document.head || document.getElementsByTagName("head")[0]
              , i = document.createElement("style");
            i.type = "text/css",
            "top" === e && r.firstChild ? r.insertBefore(i, r.firstChild) : r.appendChild(i),
            i.styleSheet ? i.styleSheet.cssText = t : i.appendChild(document.createTextNode(t))
        }
    }(".horizon-container {\n  position: relative;\n}\n\n.horizon-container .horizon-tooltip {\n  display: none;\n  position: absolute;\n  max-width: 320px;\n  white-space: nowrap;\n  padding: 5px;\n  border-radius: 3px;\n  font: 12px sans-serif;\n  color: #eee;\n  background: rgba(0,0,0,0.65);\n  pointer-events: none;\n}\n\n.horizon-container.clickable {\n  cursor: pointer;\n}");
    var uu = 25
      , lu = Ba({
        props: {
            width: {
                default: window.innerWidth
            },
            height: {
                default: 40
            },
            data: {
                default: []
            },
            bands: {
                default: 4
            },
            mode: {
                default: "offset"
            },
            x: {
                default: function(t) {
                    return t[0]
                }
            },
            y: {
                default: function(t) {
                    return t[1]
                }
            },
            xMin: {},
            xMax: {},
            yExtent: {},
            yScaleExp: {
                default: 1
            },
            yAggregation: {
                default: function(t) {
                    return t.reduce((function(t, n) {
                        return t + n
                    }
                    ))
                }
            },
            positiveColors: {
                default: ["white", "midnightblue"]
            },
            negativeColors: {
                default: ["white", "crimson"]
            },
            positiveColorStops: {},
            negativeColorStops: {},
            interpolationCurve: {
                default: Ha,
                onChange: function(t, n) {
                    return n.area.curve(t || Da)
                }
            },
            duration: {
                default: 0,
                triggerUpdate: !1
            },
            tooltipContent: {
                default: function(t) {
                    var n = t.x
                      , e = t.y;
                    return "<b>".concat(n, "</b>: ").concat(e)
                },
                triggerUpdate: !1
            },
            onHover: {
                triggerUpdate: !1
            },
            onClick: {
                triggerUpdate: !1
            }
        },
        stateInit: function() {
            return {
                area: ja(),
                xScale: Qr(),
                yScale: ei(),
                colorScale: Qr()
            }
        },
        init: function(t, n, e) {
            var r = e.useCanvas
              , i = void 0 === r || r
              , o = bt(!!t && "object" === eu(t) && !!t.node && "function" == typeof t.node ? t.node() : t);
            o.html(null);
            var a = n.container = o.append("div");
            a.attr("class", "horizon-container"),
            n.tooltip = a.append("div").attr("class", "horizon-tooltip"),
            n.useCanvas = i,
            i ? (n.canvas = a.append("canvas"),
            n.phantomDom = bt(document.createElement("phantom"))) : n.svg = a.append("svg"),
            n[i ? "canvas" : "svg"].style("display", "block").attr("width", n.width).attr("height", n.height)
        },
        update: function(t) {
            var n = Za(t.x)
              , e = Za(t.y)
              , r = nu(t.data, (function(t) {
                return +n(t)
            }
            ))
              , i = Object.entries(r).map((function(n) {
                var r = ru(n, 2)
                  , i = r[0]
                  , o = r[1];
                return [+i, t.yAggregation(o.map(e)), o]
            }
            )).sort((function(t, n) {
                return ru(t, 1)[0] - ru(n, 1)[0]
            }
            ))
              , o = void 0 !== t.xMin && null !== t.xMin ? t.xMin : i.length ? i[0][0] : 0
              , a = void 0 !== t.xMax && null !== t.xMax ? t.xMax : i.length ? i[i.length - 1][0] : 1
              , u = i.map((function(t) {
                return ru(t, 1)[0]
            }
            ))
              , l = Math.max.apply(Math, iu(u.filter((function(t) {
                return t <= o
            }
            ))))
              , s = Math.min.apply(Math, iu(u.filter((function(t) {
                return t >= a
            }
            ))));
            i = i.filter((function(t) {
                var n = ru(t, 1)[0];
                return n >= l && n <= s
            }
            ));
            var c = t.yExtent || Math.max.apply(Math, [0].concat(iu(i.map((function(t) {
                return Math.abs(t[1])
            }
            )))));
            t.xScale.domain([o, a]).range([0, t.width]),
            t.yScale.domain([0, c]).range([0, t.height * t.bands]).exponent(Math.abs(t.yScaleExp || 1));
            var f = {}
              , h = {};
            ["negative", "positive"].forEach((function(n) {
                var e = "".concat(n, "Colors")
                  , r = "".concat(n, "ColorStops")
                  , i = t[e].slice()
                  , o = (t[r] || []).slice().sort((function(t, n) {
                    return t - n
                }
                ));
                if (i.length < 2)
                    throw new Error("".concat(e, " (").concat(JSON.stringify(i), ") must include at least 2 colors"));
                if (o.some((function(t) {
                    return t <= 0 || t >= 1
                }
                )))
                    throw new Error("".concat(r, " (").concat(JSON.stringify(o), ") must only include values within ]0, 1["));
                var a = [0].concat(iu(o.slice(0, i.length - 2)))
                  , u = a.pop();
                a = a.concat(function(t) {
                    var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0
                      , e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
                    return iu(new Array(t)).map((function(t, n) {
                        return n
                    }
                    )).map(Qr().domain([0, t - 1]).range([n, e]))
                }(i.length - a.length, u, 1)),
                f[n] = a,
                h[n] = i
            }
            )),
            t.colorScale.domain([].concat(iu(f.negative.map((function(t) {
                return -t
            }
            )).reverse()), iu(f.positive)).map((function(n) {
                return Math.round(n * t.bands)
            }
            ))).range([].concat(iu(h.negative.reverse()), iu(h.positive)));
            var p = null;
            t[t.useCanvas ? "canvas" : "svg"].on("click", (function() {
                t.onClick && t.onClick(p ? {
                    x: p[0],
                    y: p[1],
                    points: p[2]
                } : null)
            }
            )).on("mousemove", (function(n) {
                if (t.onHover || t.onClick || t.tooltipContent) {
                    var e = xt(n)
                      , r = function(n) {
                        var e = null
                          , r = 1 / 0;
                        return i.some((function(t) {
                            var i = Math.abs(n - t[0]);
                            if (i > r)
                                return !0;
                            r = i,
                            e = t
                        }
                        )),
                        t.xScale(r) - t.xScale(0) > uu ? null : e
                    }(t.xScale.invert(e[0]));
                    if (t.tooltip.style("display", t.tooltipContent && r ? "inline" : "none"),
                    t.tooltipContent && t.tooltip.style("left", e[0] + "px").style("top", e[1] + "px").style("transform", "translate(-".concat(e[0] / t.width * 100, "%, 25px)")),
                    p !== r) {
                        var o = (p = r) ? {
                            x: p[0],
                            y: p[1],
                            points: p[2]
                        } : null;
                        t.onHover && t.onHover(o),
                        o && t.tooltipContent && t.tooltip.html(t.tooltipContent(o))
                    }
                }
            }
            )).on("mouseleave", (function() {
                t.tooltip.style("display", "none"),
                p = null,
                t.onHover && t.onHover(null)
            }
            )),
            t.container.node().classList[t.onClick ? "add" : "remove"]("clickable");
            var d = Mr(-1, -t.bands - 1, -1).concat(Mr(1, t.bands + 1));
            t.useCanvas ? function() {
                var n = t.phantomDom.selectAll("band").data(d, Number)
                  , e = (o = t.bands,
                a = t.height,
                u = t.mode,
                "offset" === u ? function(t) {
                    return (t + (t < 0) - o) * a
                }
                : function(t) {
                    return (t - o) * a
                }
                )
                  , r = function(t) {
                    return function(n) {
                        return "offset" === t || n >= 0 ? 1 : -1
                    }
                }(t.mode);
                var o, a, u;
                n.exit().transition().duration(t.duration).attr("yTranslate", e).attr("yScale", r).remove();
                var l = n.enter().append("band").attr("fillColor", t.colorScale).attr("yTranslate", e).attr("yScale", r).attr("ySize", 0);
                n.merge(l).transition().duration(t.duration).attr("fillColor", t.colorScale).attr("yTranslate", e).attr("yScale", r).attr("ySize", 1),
                t.phantomDom.attr("canvasWidth") || t.phantomDom.attr("canvasWidth", t.width);
                t.phantomDom.attr("canvasHeight") || t.phantomDom.attr("canvasHeight", t.height);
                t.phantomDom.transition().duration(t.duration).attr("canvasWidth", t.width).attr("canvasHeight", t.height).tween("drawAnimate", (function() {
                    return c
                }
                ));
                var s = t.canvas.node().getContext("2d");
                function c() {
                    var n = t.phantomDom.attr("canvasWidth")
                      , e = t.phantomDom.attr("canvasHeight");
                    t.canvas.attr("width", n).attr("height", e),
                    s.clearRect(0, 0, n, e),
                    t.phantomDom.selectAll("band").each((function() {
                        var n = bt(this);
                        s.save(),
                        s.scale(1, n.attr("yScale")),
                        s.translate(0, n.attr("yTranslate")),
                        s.beginPath(),
                        t.area.y1((function(e) {
                            return t.height * t.bands - t.yScale(e[1]) * n.attr("ySize")
                        }
                        ))(i),
                        s.restore(),
                        s.fillStyle = n.attr("fillColor"),
                        s.fill()
                    }
                    ))
                }
                t.area.x((function(n) {
                    return t.xScale(n[0])
                }
                )).y0(t.height * t.bands).context(s)
            }() : function() {
                t.svg.transition().duration(t.duration).attr("width", t.width).attr("height", t.height);
                var n = t.height * t.bands
                  , e = t.area.x((function(n) {
                    return t.xScale(n[0])
                }
                )).y0(n).y1(n)(i)
                  , r = t.area.y1((function(n) {
                    return t.height * t.bands - t.yScale(n[1])
                }
                ))(i)
                  , o = (u = t.bands,
                l = t.height,
                s = t.mode,
                "offset" === s ? function(t) {
                    return "translate(0,".concat((t + (t < 0) - u) * l, ")")
                }
                : function(t) {
                    return "".concat(t < 0 ? "scale(1,-1)" : "", " translate(0,").concat((t - u) * l, ")")
                }
                )
                  , a = t.svg.selectAll("path").data(d, Number);
                var u, l, s;
                a.exit().transition().duration(t.duration).attr("transform", o).remove();
                var c = a.enter().append("path").style("fill", t.colorScale).attr("transform", o).attr("d", e);
                a.merge(c).transition().duration(t.duration).style("fill", t.colorScale).attr("transform", o).attr("d", r)
            }()
        }
    })
      , su = "Expected a function"
      , cu = "__lodash_hash_undefined__"
      , fu = "[object Function]"
      , hu = "[object GeneratorFunction]"
      , pu = /^\[object .+?Constructor\]$/
      , du = "object" == typeof Fa && Fa && Fa.Object === Object && Fa
      , yu = "object" == typeof self && self && self.Object === Object && self
      , gu = du || yu || Function("return this")();
    var vu, mu = Array.prototype, _u = Function.prototype, wu = Object.prototype, bu = gu["__core-js_shared__"], xu = (vu = /[^.]+$/.exec(bu && bu.keys && bu.keys.IE_PROTO || "")) ? "Symbol(src)_1." + vu : "", Mu = _u.toString, Su = wu.hasOwnProperty, Cu = wu.toString, Tu = RegExp("^" + Mu.call(Su).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"), Au = mu.splice, ku = Ou(gu, "Map"), Eu = Ou(Object, "create");
    function zu(t) {
        var n = -1
          , e = t ? t.length : 0;
        for (this.clear(); ++n < e; ) {
            var r = t[n];
            this.set(r[0], r[1])
        }
    }
    function $u(t) {
        var n = -1
          , e = t ? t.length : 0;
        for (this.clear(); ++n < e; ) {
            var r = t[n];
            this.set(r[0], r[1])
        }
    }
    function Du(t) {
        var n = -1
          , e = t ? t.length : 0;
        for (this.clear(); ++n < e; ) {
            var r = t[n];
            this.set(r[0], r[1])
        }
    }
    function Nu(t, n) {
        for (var e, r, i = t.length; i--; )
            if ((e = t[i][0]) === (r = n) || e != e && r != r)
                return i;
        return -1
    }
    function Uu(t) {
        if (!Hu(t) || (n = t,
        xu && xu in n))
            return !1;
        var n, e = function(t) {
            var n = Hu(t) ? Cu.call(t) : "";
            return n == fu || n == hu
        }(t) || function(t) {
            var n = !1;
            if (null != t && "function" != typeof t.toString)
                try {
                    n = !!(t + "")
                } catch (t) {}
            return n
        }(t) ? Tu : pu;
        return e.test(function(t) {
            if (null != t) {
                try {
                    return Mu.call(t)
                } catch (t) {}
                try {
                    return t + ""
                } catch (t) {}
            }
            return ""
        }(t))
    }
    function ju(t, n) {
        var e, r, i = t.__data__;
        return ("string" == (r = typeof (e = n)) || "number" == r || "symbol" == r || "boolean" == r ? "__proto__" !== e : null === e) ? i["string" == typeof n ? "string" : "hash"] : i.map
    }
    function Ou(t, n) {
        var e = function(t, n) {
            return null == t ? void 0 : t[n]
        }(t, n);
        return Uu(e) ? e : void 0
    }
    function Pu(t, n) {
        if ("function" != typeof t || n && "function" != typeof n)
            throw new TypeError(su);
        var e = function() {
            var r = arguments
              , i = n ? n.apply(this, r) : r[0]
              , o = e.cache;
            if (o.has(i))
                return o.get(i);
            var a = t.apply(this, r);
            return e.cache = o.set(i, a),
            a
        };
        return e.cache = new (Pu.Cache || Du),
        e
    }
    function Hu(t) {
        var n = typeof t;
        return !!t && ("object" == n || "function" == n)
    }
    zu.prototype.clear = function() {
        this.__data__ = Eu ? Eu(null) : {}
    }
    ,
    zu.prototype.delete = function(t) {
        return this.has(t) && delete this.__data__[t]
    }
    ,
    zu.prototype.get = function(t) {
        var n = this.__data__;
        if (Eu) {
            var e = n[t];
            return e === cu ? void 0 : e
        }
        return Su.call(n, t) ? n[t] : void 0
    }
    ,
    zu.prototype.has = function(t) {
        var n = this.__data__;
        return Eu ? void 0 !== n[t] : Su.call(n, t)
    }
    ,
    zu.prototype.set = function(t, n) {
        return this.__data__[t] = Eu && void 0 === n ? cu : n,
        this
    }
    ,
    $u.prototype.clear = function() {
        this.__data__ = []
    }
    ,
    $u.prototype.delete = function(t) {
        var n = this.__data__
          , e = Nu(n, t);
        return !(e < 0) && (e == n.length - 1 ? n.pop() : Au.call(n, e, 1),
        !0)
    }
    ,
    $u.prototype.get = function(t) {
        var n = this.__data__
          , e = Nu(n, t);
        return e < 0 ? void 0 : n[e][1]
    }
    ,
    $u.prototype.has = function(t) {
        return Nu(this.__data__, t) > -1
    }
    ,
    $u.prototype.set = function(t, n) {
        var e = this.__data__
          , r = Nu(e, t);
        return r < 0 ? e.push([t, n]) : e[r][1] = n,
        this
    }
    ,
    Du.prototype.clear = function() {
        this.__data__ = {
            hash: new zu,
            map: new (ku || $u),
            string: new zu
        }
    }
    ,
    Du.prototype.delete = function(t) {
        return ju(this, t).delete(t)
    }
    ,
    Du.prototype.get = function(t) {
        return ju(this, t).get(t)
    }
    ,
    Du.prototype.has = function(t) {
        return ju(this, t).has(t)
    }
    ,
    Du.prototype.set = function(t, n) {
        return ju(this, t).set(t, n),
        this
    }
    ,
    Pu.Cache = Du;
    var Fu = Pu
      , Yu = {
        second: di,
        minute: yi,
        hour: vi,
        day: _i,
        week: Mi,
        month: Hi,
        year: Yi
    }
      , Iu = {
        second: di,
        minute: gi,
        hour: mi,
        day: wi,
        week: $i,
        month: Fi,
        year: Ii
    }
      , Lu = {
        millisecond: function() {
            return ".%L"
        },
        second: function() {
            return ":%S"
        },
        minute: function(t) {
            var n = t.use24h;
            return "%".concat(n ? "H" : "I", ":%M")
        },
        hour: function(t) {
            return t.use24h ? "%H:%M" : "%I %p"
        },
        day: function() {
            return "%a %d"
        },
        week: function() {
            return "%b %d"
        },
        month: function() {
            return "%b"
        },
        year: function() {
            return "%Y"
        }
    };
    var qu = ["x", "y"]
      , Xu = Ba({
        props: {
            width: {
                default: window.innerWidth
            },
            height: {
                default: window.innerHeight
            },
            data: {
                default: []
            },
            ts: {
                default: "ts"
            },
            val: {
                default: "val"
            },
            series: {},
            seriesComparator: {
                default: function(t, n) {
                    return t.localeCompare(n)
                }
            },
            horizonBands: {
                default: 4
            },
            horizonMode: {
                default: "offset"
            },
            useUtc: {
                default: !1
            },
            use24h: {
                default: !0
            },
            yExtent: {},
            yNormalize: {
                default: !1
            },
            yScaleExp: {
                default: 1
            },
            yAggregation: {
                default: function(t) {
                    return t.reduce((function(t, n) {
                        return t + n
                    }
                    ))
                }
            },
            positiveColors: {
                default: ["white", "midnightblue"]
            },
            negativeColors: {
                default: ["white", "crimson"]
            },
            positiveColorStops: {},
            negativeColorStops: {},
            interpolationCurve: {
                default: Ha
            },
            seriesLabelFormatter: {
                default: function(t) {
                    return t
                }
            },
            showRuler: {
                default: !0,
                triggerUpdate: !1,
                onChange: function(t, n) {
                    return n.ruler && n.ruler.style("visibility", t ? "visible" : "hidden")
                }
            },
            enableZoom: {
                default: !1
            },
            tooltipContent: {
                default: function(t) {
                    var n = t.series
                      , e = t.ts
                      , r = t.val
                      , i = t.useUtc
                      , o = t.use24h;
                    return "<b>".concat(n, "</b><br>\n      ").concat(new Date(e).toLocaleString(void 0, {
                        timeZone: i ? "UTC" : void 0,
                        hour12: !o
                    }), ":\n      <b>").concat(r, "</b>")
                }
            },
            transitionDuration: {
                default: 250
            },
            onHover: {
                triggerUpdate: !1
            },
            onClick: {}
        },
        stateInit: function() {
            return {
                horizonLayouts: {},
                zoomedInteraction: !1,
                timeAxis: cr(er, t)
            };
            var t
        },
        init: function(t, n) {
            var r = bt(!!t && "object" === e(t) && !!t.node && "function" == typeof t.node ? t.node() : t);
            r.html(null),
            n.chartsEl = r.append("div").style("position", "relative"),
            n.ruler = n.chartsEl.append("div").attr("class", "horizon-ruler"),
            n.axisEl = r.append("svg").attr("height", 20).style("display", "block"),
            n.chartsEl.call(n.zoom = Je()),
            n.zoom.__baseElem = n.chartsEl,
            n.zoom.on("zoom", (function() {
                n.enableZoom && (n.zoomedInteraction = !0,
                n._rerender())
            }
            ))
        },
        update: function(t) {
            var e, u, l, s, c, f, h, p, d = Za(t.val), y = Za(t.yExtent), g = Za(t.yScaleExp), v = Za(t.positiveColors), m = Za(t.negativeColors), _ = Za(t.positiveColorStops), w = Za(t.negativeColorStops), b = Fu(Za(t.ts)), x = t.data.map(b), M = (t.useUtc ? ba : wa)().domain(function(t, n) {
                let e, r;
                if (void 0 === n)
                    for (const n of t)
                        null != n && (void 0 === e ? n >= n && (e = r = n) : (e > n && (e = n),
                        r < n && (r = n)));
                else {
                    let i = -1;
                    for (let o of t)
                        null != (o = n(o, ++i, t)) && (void 0 === e ? o >= o && (e = r = o) : (e > o && (e = o),
                        r < o && (r = o)))
                }
                return [e, r]
            }(x)).range([0, t.width]);
            if (t.timeAxis.scale(M).tickFormat((e = {
                useUtc: t.useUtc,
                use24h: t.use24h
            },
            u = e.useUtc,
            l = void 0 !== u && u,
            s = e.use24h,
            c = {
                use24h: void 0 !== s && s
            },
            f = l ? Ji : Qi,
            h = Object.assign.apply(Object, [{}].concat(a(Object.entries(Lu).map((function(t) {
                var n = o(t, 2)
                  , e = n[0]
                  , i = n[1];
                return r({}, e, f(i(c)))
            }
            ))))),
            p = l ? Iu : Yu,
            function(t) {
                return (p.second(t) < t ? h.millisecond : p.minute(t) < t ? h.second : p.hour(t) < t ? h.minute : p.day(t) < t ? h.hour : p.month(t) < t ? p.week(t) < t ? h.day : h.week : p.year(t) < t ? h.month : h.year)(t)
            }
            )),
            t.zoom.scaleExtent([1, t.enableZoom ? 5e3 : 1]),
            t.enableZoom) {
                t.zoom.translateExtent([[0, 0], [t.width, 0]]);
                var S = qe(t.zoom.__baseElem.node())
                  , C = (M.domain()[1] - M.domain()[0]) / S.k
                  , T = M.invert(-S.x / S.k);
                M.domain([T, new Date(+T + C)])
            }
            var A = nu(t.data, t.series)
              , k = Object.keys(A).sort(t.seriesComparator).map((function(t) {
                return {
                    series: t,
                    data: A[t]
                }
            }
            ))
              , E = t.yNormalize ? function(t, n) {
                let e;
                if (void 0 === n)
                    for (const n of t)
                        null != n && (e < n || void 0 === e && n >= n) && (e = n);
                else {
                    let r = -1;
                    for (let i of t)
                        null != (i = n(i, ++r, t)) && (e < i || void 0 === e && i >= i) && (e = i)
                }
                return e
            }(nu(t.data, [t.series, function(t) {
                return +b(t)
            }
            ], (function(n) {
                return t.yAggregation(n.map(d))
            }
            ), !0).map((function(t) {
                return t.vals
            }
            )).map(Math.abs)) : null
              , z = (t.height - 20) / k.length
              , $ = Math.min(13, Math.round(.9 * z))
              , D = z >= 20 ? 1 : 0
              , N = De().duration(t.zoomedInteraction ? 0 : t.transitionDuration)
              , U = t.chartsEl.selectAll(".horizon-series").data(k, (function(t) {
                return t.series
            }
            ));
            U.exit().each((function(n) {
                var e = n.series;
                t.horizonLayouts[e].height(0),
                delete t.horizonLayouts[e]
            }
            )).transition(N).remove();
            var j = U.enter().append("div").attr("class", "horizon-series");
            j.append("div").attr("class", "chart").each((function(n) {
                var e = n.series;
                t.horizonLayouts[e] = lu().width(t.width).height(z - D)(this)
            }
            )),
            j.append("span").attr("class", "label").style("font-size", 0);
            var O = U.merge(j).order();
            O.transition(N).style("width", t.width).style("border-top-width", "".concat(D, "px")),
            O.select(".chart").each((function(e) {
                var r = e.series
                  , o = e.data;
                return t.horizonLayouts[r].width(t.width).height(z - D).data(o).bands(t.horizonBands).mode(t.horizonMode).x(b).y(d).yExtent(y(r) || E || null).yScaleExp(g(r)).yAggregation(t.yAggregation).xMin(M.domain()[0]).xMax(M.domain()[1]).positiveColors(v(r)).negativeColors(m(r)).positiveColorStops(_(r)).negativeColorStops(w(r)).interpolationCurve(t.interpolationCurve).duration(t.transitionDuration).tooltipContent(t.tooltipContent && function(e) {
                    var o = e.x
                      , a = e.y
                      , u = i(e, qu);
                    return t.tooltipContent(n(n({
                        series: r,
                        ts: o,
                        val: a
                    }, u), {}, {
                        useUtc: t.useUtc,
                        use24h: t.use24h
                    }))
                }
                ).onHover((function(n) {
                    n && t.ruler.style("left", "".concat(M(n.x), "px")),
                    t.ruler.style("opacity", n ? .2 : 0),
                    n && t.onHover && t.onHover({
                        series: r,
                        ts: n.x,
                        val: n.y,
                        points: n.points
                    })
                }
                )).onClick(t.onClick ? function(n) {
                    return n && t.onClick({
                        series: r,
                        ts: n.x,
                        val: n.y,
                        points: n.points
                    })
                }
                : void 0)
            }
            )),
            O.select(".label").transition(N).style("font-size", "".concat($, "px")).text((function(n) {
                return t.seriesLabelFormatter(n.series)
            }
            )),
            t.axisEl.call(t.timeAxis).transition(N).attr("width", t.width),
            t.zoomedInteraction = !1
        }
    });
    return Xu
}
));
